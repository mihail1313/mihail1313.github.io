"""Standalone desktop UI. Run with Python 3.11+ and openpyxl."""

from __future__ import annotations
import copy, os, sys, traceback, uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from hydraulics import (
    empty_project,
    demo_project,
    calculate,
    load_project,
    save_project,
    number,
    water_properties,
    effective_system,
    InputError,
    validate_project,
    readiness,
    file_digest,
    APP_VERSION,
)
from project_ops import edit_row, delete_rows, bulk_update, History
from excel_io import import_table, sheet_names, create_template, export_results

# key, label, kind. No implicit conversions of nominal to inner diameter.
FIELDS = {
    "systems": [
        ("id", "Номер системы / насосного контура", "text"),
        ("name", "Название", "text"),
        ("properties_mode", "Свойства теплоносителя", "mode"),
        ("supply_c", "Подача, °C", "float"),
        ("return_c", "Обратка, °C", "float"),
        ("coolant", "Теплоноситель", "text"),
        ("rho", "Плотность, кг/м³", "float"),
        ("cp", "Теплоёмкость, Дж/(кг·К)", "float"),
        ("nu_mm2_s", "Кинематическая вязкость, мм²/с", "float"),
        ("flow_margin_percent", "Запас расхода, %", "float"),
        ("head_margin_percent", "Запас напора, %", "float"),
        ("velocity_limit_ms", "Контроль скорости, м/с", "float"),
    ],
    "branches": [
        ("id", "Уникальный номер ветки", "text"),
        ("system_id", "Номер системы", "system"),
        ("collector_id", "Номер коллектора", "text"),
        ("name", "Название / прибор", "text"),
        ("heat_w", "Расчётная мощность ветки, Вт", "float"),
        ("main_path", "ID магистралей пути через ; (подача + обратка)", "path"),
        ("path_complete", "Учтён весь путь насоса и все сопротивления", "bool"),
    ],
    "segments": [
        ("id", "Уникальный ID участка", "text"),
        ("branch_id", "Номер ветки", "branch"),
        ("length_m", "Длина труб, м (подача + обратка либо часть пути)", "float"),
        ("inner_mm", "Внутренний диаметр, мм", "float"),
        ("roughness_mm", "Шероховатость, мм", "float"),
        ("zeta", "Сумма КМС при скорости этого участка", "float"),
        ("kv_m3h", "Kv изделия, м³/ч (необязательно)", "optional"),
        ("extra_dp_pa", "Другие потери при расчётном расходе, Па", "float"),
        ("extra_model", "Зависимость дополнительных потерь от расхода", "law"),
    ],
    "mains": [
        ("id", "Уникальный ID магистрали", "text"),
        ("system_id", "Номер системы", "system"),
        ("name", "Название / подача или обратка", "text"),
        ("length_m", "Длина участка, м", "float"),
        ("inner_mm", "Внутренний диаметр, мм", "float"),
        ("roughness_mm", "Шероховатость, мм", "float"),
        ("zeta", "Сумма КМС при скорости этого участка", "float"),
        ("kv_m3h", "Kv изделия, м³/ч (необязательно)", "optional"),
        ("extra_dp_pa", "Другие потери при расчётном расходе, Па", "float"),
        ("extra_model", "Зависимость дополнительных потерь от расхода", "law"),
    ],
}
CHOICES = {
    "mode": {
        "water_auto": "Вода — автоматически по температуре",
        "manual": "Свойства введены вручную",
    },
    "law": {
        "design": "Известны только при проектном расходе",
        "quadratic": "Пропорциональны квадрату расхода",
    },
}
FONT = "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"
TITLES = {
    "systems": "1. Системы",
    "branches": "2. Ветки",
    "segments": "3. Участки веток",
    "mains": "4. Магистрали",
}


class Editor(tk.Toplevel):
    def __init__(self, parent, key, row, on_save):
        super().__init__(parent)
        self.title("Свойства")
        self.transient(parent)
        self.grab_set()
        self.owner = parent
        self.key = key
        self.row = copy.deepcopy(row)
        self.on_save = on_save
        self.values = {}
        self.widgets = {}
        self.resizable(True, True)
        frame = ttk.Frame(self, padding=18)
        frame.pack(fill="both", expand=True)
        for r, (name, label, kind) in enumerate(FIELDS[key]):
            ttk.Label(frame, text=label).grid(row=r, column=0, sticky="w", padx=(0, 12), pady=3)
            value = row.get(
                name,
                {"properties_mode": "manual", "extra_model": "design", "velocity_limit_ms": 1}.get(
                    name, ""
                ),
            )
            if kind == "bool":
                var = tk.BooleanVar(value=bool(value))
                widget = ttk.Checkbutton(frame, variable=var)
            else:
                if kind == "path":
                    value = "; ".join(value or [])
                elif kind in CHOICES:
                    value = CHOICES[kind].get(value, value)
                var = tk.StringVar(value="" if value is None else str(value))
                if kind in ("mode", "law"):
                    widget = ttk.Combobox(
                        frame,
                        textvariable=var,
                        values=list(CHOICES[kind].values()),
                        state="readonly",
                        width=42,
                    )
                elif kind in ("system", "branch"):
                    items = parent.project["systems" if kind == "system" else "branches"]
                    widget = ttk.Combobox(
                        frame, textvariable=var, values=[str(x["id"]) for x in items], width=42
                    )
                else:
                    widget = ttk.Entry(frame, textvariable=var, width=44)
            widget.grid(row=r, column=1, sticky="ew", pady=3)
            self.values[name] = var
            self.widgets[name] = widget
        nr = len(FIELDS[key])
        buttons = ttk.Frame(frame)
        buttons.grid(row=nr, column=0, columnspan=2, sticky="e", pady=(14, 0))
        if key == "systems":
            ttk.Button(
                buttons, text="Свойства воды по средней температуре", command=self.water
            ).pack(side="left", padx=4)
        ttk.Button(buttons, text="Сохранить", command=self.commit).pack(side="left", padx=4)
        ttk.Button(buttons, text="Отмена", command=self.destroy).pack(side="left", padx=4)
        frame.columnconfigure(1, weight=1)
        self.bind("<Escape>", lambda e: self.destroy())
        if key == "systems":
            for name in ("properties_mode", "supply_c", "return_c"):
                self.values[name].trace_add("write", self.update_water)
            self.update_water()
        self.bind("<Control-z>", lambda e: "break")
        self.bind("<Control-y>", lambda e: "break")

    def update_water(self, *args):
        automatic = self.values["properties_mode"].get() == CHOICES["mode"]["water_auto"]
        if automatic:
            try:
                mean = (
                    number(self.values["supply_c"].get(), "Подача", minimum=-100)
                    + number(self.values["return_c"].get(), "Обратка", minimum=-100)
                ) / 2
                for k, v in water_properties(mean).items():
                    self.values[k].set(f"{v:.8g}")
                self.values["coolant"].set("Вода")
            except InputError:
                pass  # An incomplete keystroke is validated on Save.
        for key in ("rho", "cp", "nu_mm2_s", "coolant"):
            self.widgets[key].config(state="readonly" if automatic else "normal")

    def water(self):
        try:
            mean = (
                number(self.values["supply_c"].get(), "Подача", minimum=-100)
                + number(self.values["return_c"].get(), "Обратка", minimum=-100)
            ) / 2
            props = water_properties(mean)
            for k, v in props.items():
                self.values[k].set(f"{v:.8g}")
            self.values["coolant"].set("Вода")
            self.values["properties_mode"].set(CHOICES["mode"]["water_auto"])
        except ValueError as e:
            messagebox.showerror("Исходные данные", str(e), parent=self)

    def commit(self):
        try:
            updated = copy.deepcopy(self.row)
            for key, label, kind in FIELDS[self.key]:
                v = self.values[key].get()
                if kind in ("float", "optional"):
                    v = (
                        None
                        if kind == "optional" and not v.strip()
                        else number(
                            v, label, minimum=-100 if key in ("supply_c", "return_c") else 0
                        )
                    )
                elif kind == "path":
                    v = [a.strip() for a in v.split(";") if a.strip()]
                elif kind in CHOICES:
                    v = next(k for k, label in CHOICES[kind].items() if label == v)
                elif kind != "bool":
                    v = str(v).strip()
                if kind in ("text", "system", "branch") and not v:
                    raise InputError(f"Заполните «{label}».")
                updated[key] = v
            if self.key == "systems":
                updated = effective_system(updated)
            self.on_save(updated)
            self.destroy()
        except (ValueError, KeyError) as e:
            messagebox.showerror("Проверьте ввод", str(e), parent=self)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        from tkinter import font as tkfont

        for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            tkfont.nametofont(name).configure(family=FONT, size=10)
        self.title("Гидравлика — инженерный калькулятор " + APP_VERSION)
        self.geometry("1280x820")
        self.minsize(960, 640)
        self.project = empty_project()
        self.path = None
        self.dirty = False
        self.result = None
        self.trees = {}
        self.filters = {}
        self.table_frames = {}
        self.history = History()
        self.disk_digest = None
        self.autosave_path = (
            Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
            / "HeatingCalculator"
            / ("recovery-" + str(os.getpid()) + "-" + uuid.uuid4().hex[:8] + ".json")
        )
        self.report_callback_exception = self.exception
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Treeview", rowheight=28)
        style.configure("Treeview.Heading", font=(FONT, 10, "bold"))
        style.configure("Title.TLabel", font=(FONT, 18, "bold"))
        header = ttk.Frame(self, padding=(18, 14))
        header.pack(fill="x")
        ttk.Label(header, text="Гидравлика", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="  Отопление · проектные расходы и потери давления").pack(
            side="left", padx=15
        )
        bar = ttk.Frame(self, padding=(14, 0, 14, 10))
        bar.pack(fill="x")
        actions = [
            ("Новый", self.new),
            ("Открыть JSON", self.open),
            ("Сохранить", self.save),
            ("Сохранить как…", lambda: self.save(True)),
            ("Импорт Excel / CSV", self.import_excel),
            ("Шаблон Excel", self.template),
            ("Пример", self.demo),
            ("Проверить данные", self.check),
            ("Рассчитать", self.run),
            ("Экспорт результатов", self.export),
            ("Отменить", self.undo),
            ("Повторить", self.redo),
            ("Восстановить", self.recover),
        ]
        for i, (title, cmd) in enumerate(actions):
            ttk.Button(bar, text=title, command=cmd).grid(
                row=i // 7, column=i % 7, sticky="ew", padx=3, pady=3
            )
        for i in range(7):
            bar.columnconfigure(i, weight=1)
        self.bind("<Control-s>", lambda e: self.save())
        self.bind("<Control-z>", lambda e: self.undo())
        self.bind("<Control-y>", lambda e: self.redo())
        self.project_label = ttk.Label(self, padding=(18, 0, 18, 8))
        self.project_label.pack(fill="x")
        self.project_label.bind("<Double-1>", self.rename_project)
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=16, pady=4)
        for key, title in TITLES.items():
            self.make_table_tab(key, title)
        self.output = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.output, text="5. Результаты")
        summary_frame = ttk.Frame(self.output)
        summary_frame.pack(fill="x")
        self.summary = tk.Text(
            summary_frame, height=5, wrap="word", font=(FONT, 11), state="disabled", relief="flat"
        )
        self.scroll_text(self.summary, summary_frame, expand=False)
        columns = [
            ("id", "Ветка"),
            ("system_id", "Система"),
            ("collector_id", "Коллектор"),
            ("length_m", "Длина, м"),
            ("flow_m3h", "Расход, м³/ч"),
            ("max_velocity_ms", "v макс., м/с"),
            ("branch_dp_pa", "Подводка, Па"),
            ("main_dp_pa", "Магистраль, Па"),
            ("loop_dp_pa", "Учтено всего, Па"),
            ("balance_dp_pa", "Балансировка, Па"),
            ("path_complete", "Полнота"),
        ]
        self.result_tree = self.table(self.output, columns)
        for (key, _), width in zip(columns, [95, 70, 80, 95, 110, 100, 100, 110, 120, 115, 140]):
            self.result_tree.column(key, width=width, minwidth=65, stretch=False)
        self.details_frame = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.details_frame, text="По участкам")
        self.details_tree = self.table(
            self.details_frame,
            [
                (k, l)
                for k, l in [
                    ("id", "Участок"),
                    ("branch_id", "Ветка / система"),
                    ("inner_mm", "dвн, мм"),
                    ("length_m", "Длина, м"),
                    ("flow_m3h", "Расход, м³/ч"),
                    ("velocity_ms", "v, м/с"),
                    ("re", "Re"),
                    ("lambda", "λ"),
                    ("regime", "Режим"),
                    ("dp_linear_pa", "Трение, Па"),
                    ("dp_local_pa", "Местные, Па"),
                    ("dp_kv_pa", "Kv, Па"),
                    ("dp_extra_pa", "Доп., Па"),
                    ("dp_pa", "Всего, Па"),
                ]
            ],
        )
        self.collector_frame = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.collector_frame, text="Коллекторы")
        self.collector_tree = self.table(
            self.collector_frame,
            [
                ("system_id", "Система"),
                ("collector_id", "Коллектор"),
                ("branch_count", "Веток"),
                ("heat_w", "Мощность, Вт"),
                ("flow_m3h", "Расход, м³/ч"),
                ("length_m", "Трубы, м"),
                ("max_branch_dp_pa", "Макс. подводка, Па"),
            ],
        )
        self.diagnostics = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.diagnostics, text="Проверка")
        self.issue_tree = self.table(
            self.diagnostics,
            [("severity", "Статус"), ("id", "Объект"), ("message", "Что проверить")],
        )
        self.issue_tree.column("message", width=650)
        self.issue_tree.bind("<Double-1>", self.goto_issue)
        self.import_notes = tk.Text(self.diagnostics, height=8, wrap="word", state="disabled")
        self.import_notes.pack(side="bottom", fill="x", before=self.issue_tree.master)
        notes_frame = ttk.Frame(self.output)
        notes_frame.pack(side="bottom", fill="x", pady=(8, 0), before=self.result_tree.master)
        self.notes = tk.Text(notes_frame, height=5, wrap="word", font=(FONT, 10), state="disabled")
        self.scroll_text(self.notes, notes_frame, expand=False)
        help_frame = ttk.Frame(self.tabs, padding=20)
        self.tabs.add(help_frame, text="Порядок работы")
        try:
            help_text = Path(__file__).with_name("README.md").read_text(encoding="utf-8")
        except OSError:
            help_text = "Откройте README.md из комплекта. Создайте системы, ветки и участки; проверьте данные, затем рассчитайте."
        help_box = tk.Text(help_frame, wrap="word", font=(FONT, 11), relief="flat")
        help_box.insert("1.0", help_text)
        help_box.config(state="disabled")
        help_box.pack(fill="both", expand=True)
        self.status = tk.StringVar(value="Добавьте данные или откройте демонстрационный пример.")
        ttk.Label(self, textvariable=self.status, padding=(18, 10), wraplength=1000).pack(
            side="bottom", fill="x", before=self.tabs
        )
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()

    def rename_project(self, event=None):
        name = simpledialog.askstring(
            "Название проекта", "Название:", initialvalue=self.project.get("name", ""), parent=self
        )
        if name and name.strip():
            p = copy.deepcopy(self.project)
            p["name"] = name.strip()
            self.apply_project(p)

    def exception(self, kind, value, tb):
        detail = "".join(traceback.format_exception(kind, value, tb))
        location = "Журнал записать не удалось."
        try:
            folder = self.autosave_path.parent
            folder.mkdir(parents=True, exist_ok=True)
            log = folder / "error.log"
            with log.open("a", encoding="utf-8") as stream:
                stream.write(detail + "\n")
            location = f"Подробности: {log}"
        except OSError:
            pass
        messagebox.showerror("Операция не завершена", f"{value}\n\n{location}")

    def table(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(
            frame, columns=[k for k, _ in columns], show="headings", selectmode="extended"
        )
        for key, label in columns:
            tree.heading(key, text=label)
            tree.column(key, width=155, minwidth=90, stretch=True)
        sy = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        tree.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        return tree

    def make_table_tab(self, key, title):
        frame = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(frame, text=title)
        bar = ttk.Frame(frame)
        bar.pack(fill="x", pady=(0, 10))
        ttk.Button(bar, text="Добавить", command=lambda: self.edit(key)).pack(side="left", padx=3)
        ttk.Button(bar, text="Изменить", command=lambda: self.edit(key, True)).pack(
            side="left", padx=3
        )
        ttk.Button(bar, text="Удалить", command=lambda: self.delete(key)).pack(side="left", padx=3)
        hints = {
            "systems": "Расчётный температурный режим и свойства теплоносителя.",
            "branches": "Мощность задаётся один раз для всей ветки. Полнота кольца подтверждается отдельно.",
            "segments": "Разные внутренние диаметры — разные участки. Длины в метрах, диаметр в миллиметрах.",
            "mains": "Подача и обратка — отдельные ID. Общий участок создаётся один раз.",
        }
        if key in ("segments", "mains", "branches"):
            ttk.Button(bar, text="Изменить выбранные…", command=lambda: self.bulk(key)).pack(
                side="left", padx=3
            )
        search = tk.StringVar()
        self.filters[key] = search
        ttk.Entry(bar, textvariable=search, width=22).pack(side="right", padx=3)
        ttk.Label(bar, text="Поиск:").pack(side="right")
        search.trace_add("write", lambda *args: self.refresh_table(key))
        ttk.Label(frame, text=hints[key], wraplength=850).pack(fill="x", pady=(0, 8))
        self.table_frames[key] = frame
        tree = self.table(frame, [(k, l) for k, l, _ in FIELDS[key]])
        tree.bind("<Double-1>", lambda e: self.edit(key, True))
        self.trees[key] = tree

    def refresh(self):
        self.project_label.config(
            text=f'Проект: {self.project.get("name", "")}   |   {self.path or "Ещё не сохранён"}'
            + ("   • Есть изменения" if self.dirty else "")
        )
        for key in self.trees:
            self.refresh_table(key)

    def refresh_table(self, key):
        tree = self.trees.get(key)
        if tree is None:
            return
        selected = set(tree.selection())
        tree.delete(*tree.get_children())
        query = self.filters[key].get().strip().casefold()
        for i, row in enumerate(self.project[key]):
            if key == "systems":
                row = effective_system(row)
            vals = []
            for name, label, kind in FIELDS[key]:
                v = row.get(
                    name,
                    {
                        "properties_mode": "manual",
                        "extra_model": "design",
                        "velocity_limit_ms": 1,
                    }.get(name, ""),
                )
                if kind == "bool":
                    v = "Да" if v else "Нет"
                elif kind == "path":
                    v = "; ".join(v or [])
                elif kind in CHOICES:
                    v = CHOICES[kind].get(v, v)
                elif v is None:
                    v = ""
                vals.append(v)
            if query and query not in " ".join(map(str, vals)).casefold():
                continue
            tree.insert("", "end", iid=str(i), values=vals)
        tree.selection_set([i for i in selected if tree.exists(i)])

    def apply_project(self, project):
        validate_project(project)
        self.history.push(self.project)
        self.project = project
        self.changed()

    def changed(self):
        self.dirty = True
        self.result = None
        self.result_tree.delete(*self.result_tree.get_children())
        self.details_tree.delete(*self.details_tree.get_children())
        self.collector_tree.delete(*self.collector_tree.get_children())
        self.issue_tree.delete(*self.issue_tree.get_children())
        self.set_text(self.summary, "Данные изменены. Выполните расчёт заново.")
        self.set_text(self.notes, "")
        self.refresh()
        self.set_text(
            self.import_notes,
            "\n\n".join(
                s.get("file", "")
                + " / "
                + s.get("sheet", "")
                + "\n"
                + "\n".join(s.get("warnings", []))
                for s in self.project.get("imports", [])
            ),
        )
        try:
            self.autosave_path.parent.mkdir(parents=True, exist_ok=True)
            save_project(self.project, self.autosave_path)
        except (OSError, ValueError) as e:
            self.status.set("Не удалось записать восстановление: " + str(e))

    def edit(self, key, existing=False):
        tree = self.trees[key]
        index = None
        if existing:
            selection = tree.selection()
            if not selection:
                return
            index = int(selection[0])
            row = self.project[key][index]
        else:
            system = self.project["systems"][0]["id"] if self.project["systems"] else ""
            if key == "systems":
                from hydraulics import default_system

                row = default_system(f"1.{len(self.project[key])+1}")
            elif key == "branches":
                row = {
                    "id": f"101-{len(self.project[key])+1}",
                    "system_id": system,
                    "collector_id": "101",
                    "name": "Радиатор",
                    "heat_w": 1000,
                    "main_path": [],
                    "path_complete": False,
                }
            else:
                row = {
                    "id": f'{"У" if key=="segments" else "М"}-{len(self.project[key])+1}',
                    "length_m": 0,
                    "inner_mm": 11.6 if key == "segments" else 20,
                    "roughness_mm": 0.007,
                    "zeta": 0,
                    "kv_m3h": None,
                    "extra_dp_pa": 0,
                }
                if key == "segments":
                    row["branch_id"] = (
                        self.project["branches"][0]["id"] if self.project["branches"] else ""
                    )
                else:
                    row.update(system_id=system, name="Подача / обратка")

        def save(updated):
            self.apply_project(edit_row(self.project, key, index, updated))

        Editor(self, key, row, save)

    def delete(self, key):
        sel = self.trees[key].selection()
        if not sel:
            return
        if not messagebox.askyesno(
            "Удаление",
            f"Удалить записей: {len(sel)}? Удаление ветки включает её участки. Можно отменить кнопкой «Отменить».",
        ):
            return
        try:
            self.apply_project(delete_rows(self.project, key, [int(i) for i in sel]))
        except InputError as e:
            messagebox.showerror("Удаление", str(e))

    def bulk(self, key):
        selection = self.trees[key].selection()
        if not selection:
            messagebox.showinfo("Выбор", "Выделите строки с помощью Ctrl / Shift.")
            return
        dialog = tk.Toplevel(self)
        dialog.title("Изменить выбранные строки")
        dialog.transient(self)
        dialog.grab_set()
        options = {
            "segments": [
                ("Внутренний диаметр, мм", "inner_mm"),
                ("Шероховатость, мм", "roughness_mm"),
                ("Сумма КМС", "zeta"),
            ],
            "mains": [
                ("Внутренний диаметр, мм", "inner_mm"),
                ("Шероховатость, мм", "roughness_mm"),
                ("Сумма КМС", "zeta"),
            ],
            "branches": [
                ("Номер коллектора", "collector_id"),
                ("Магистрали пути через ;", "main_path"),
                ("Полнота: да / нет", "path_complete"),
            ],
        }[key]
        ttk.Label(dialog, text=f"Выбрано строк: {len(selection)}", padding=12).pack()
        field = tk.StringVar(value=options[0][0])
        value = tk.StringVar()
        ttk.Combobox(
            dialog, textvariable=field, values=[a for a, b in options], state="readonly", width=40
        ).pack(padx=12, pady=6)
        ttk.Entry(dialog, textvariable=value, width=42).pack(padx=12, pady=6)
        ttk.Label(
            dialog,
            text="Для полноты «да» подтвердите весь путь насоса, всех потребителей\nи сопротивления. Геометрия Revit здесь не проверяется.",
            padding=12,
        ).pack()

        def apply():
            try:
                name = dict(options)[field.get()]
                v = value.get().strip()
                if name in ("inner_mm", "roughness_mm", "zeta"):
                    v = number(v, field.get())
                elif name == "main_path":
                    v = [a.strip() for a in v.split(";") if a.strip()]
                elif name == "path_complete":
                    if v.lower() not in ("да", "нет"):
                        raise InputError("Введите «да» или «нет».")
                    v = v.lower() == "да"
                self.apply_project(
                    bulk_update(self.project, key, [int(i) for i in selection], name, v)
                )
                dialog.destroy()
            except (InputError, ValueError) as e:
                messagebox.showerror("Проверьте ввод", str(e), parent=dialog)

        ttk.Button(dialog, text="Применить", command=apply).pack(pady=12)

    def undo(self):
        if self.grab_current() is not None:
            return
        p = self.history.undo(self.project)
        if p is not None:
            self.project = p
            self.changed()
            self.status.set("Изменение отменено.")

    def redo(self):
        if self.grab_current() is not None:
            return
        p = self.history.redo(self.project)
        if p is not None:
            self.project = p
            self.changed()
            self.status.set("Изменение повторено.")

    def recover(self):
        path = filedialog.askopenfilename(
            initialdir=str(self.autosave_path.parent),
            filetypes=[("Восстановление / резервная копия", "*.json *.bak")],
        )
        if not path:
            return
        try:
            project = load_project(path)
            if self.can_replace():
                self.history = History()
                self.project = project
                self.path = None
                self.disk_digest = None
                self.changed()
        except (OSError, ValueError) as e:
            messagebox.showerror("Восстановление", str(e))

    def check(self):
        self.issue_tree.delete(*self.issue_tree.get_children())
        issues = readiness(self.project)
        for item in issues:
            self.issue_tree.insert(
                "",
                "end",
                values=[
                    "Нужно заполнить" if item["severity"] == "error" else "Проверьте",
                    item["id"],
                    item["message"],
                ],
            )
        if not issues:
            self.issue_tree.insert(
                "",
                "end",
                values=[
                    "Готово",
                    "Проект",
                    "Исходные данные заполнены. Полнота схемы подтверждается пользователем.",
                ],
            )
        self.tabs.select(self.diagnostics)
        self.status.set(
            f'Проверка: незаполненных данных {sum(i["severity"]=="error" for i in issues)}, замечаний {sum(i["severity"]=="warning" for i in issues)}.'
        )
        return issues

    def goto_issue(self, event=None):
        sel = self.issue_tree.selection()
        if not sel:
            return
        rid = str(self.issue_tree.item(sel[0], "values")[1])
        for key in ("segments", "mains", "branches", "systems"):
            for i, row in enumerate(self.project[key]):
                if row["id"] == rid:
                    self.filters[key].set("")
                    self.tabs.select(self.table_frames[key])
                    self.trees[key].selection_set(str(i))
                    self.trees[key].see(str(i))
                    self.edit(key, True)
                    return

    def can_replace(self):
        if not self.dirty:
            return True
        decision = messagebox.askyesnocancel("Проект изменён", "Сохранить текущий проект?")
        if decision is None:
            return False
        return bool(self.save()) if decision else True

    def new(self):
        if not self.can_replace():
            return
        self.project = empty_project()
        self.path = None
        self.disk_digest = None
        self.history = History()
        self.changed()
        self.dirty = False
        self.refresh()

    def demo(self):
        if not self.can_replace():
            return
        self.history = History()
        self.project = demo_project()
        self.path = None
        self.disk_digest = None
        self.changed()
        self.run()

    def open(self):
        if not self.can_replace():
            return
        path = filedialog.askopenfilename(filetypes=[("Проект калькулятора", "*.json")])
        if not path:
            return
        try:
            project = load_project(path)
            self.history = History()
            self.project = project
            self.path = path
            self.disk_digest = file_digest(path)
            self.changed()
            self.dirty = False
            self.refresh()
            self.status.set("Проект открыт. Проверьте исходные данные и выполните расчёт.")
        except (ValueError, KeyError, OSError) as e:
            messagebox.showerror("Не удалось открыть", str(e))

    def save(self, save_as=False):
        path = (
            self.path
            if self.path and not save_as
            else filedialog.asksaveasfilename(
                defaultextension=".json",
                initialfile=Path(self.path).name if self.path else "Отопление.json",
                filetypes=[("Проект", "*.json")],
            )
        )
        if not path:
            return False
        try:
            save_project(
                self.project,
                path,
                expected_digest=self.disk_digest if path == self.path else "unchecked",
            )
            self.path = path
            self.disk_digest = file_digest(path)
            self.dirty = False
            self.refresh()
            self.status.set("Проект сохранён.")
            return True
        except (ValueError, OSError) as e:
            messagebox.showerror("Не удалось сохранить", str(e))
            return False

    def import_excel(self):
        path = filedialog.askopenfilename(
            filetypes=[("Ведомость Excel / CSV / Revit", "*.xlsx *.csv *.tsv *.txt")]
        )
        if not path:
            return
        try:
            names = sheet_names(path)
        except Exception as e:
            messagebox.showerror("Импорт", str(e))
            return
        dialog = tk.Toplevel(self)
        dialog.title("Предпросмотр импорта")
        dialog.transient(self)
        dialog.grab_set()
        dialog.geometry("880x640")
        ttk.Label(dialog, text="Выберите лист исходной ведомости:", padding=10).pack(anchor="w")
        selected = tk.StringVar(value=names[0])
        ttk.Combobox(dialog, textvariable=selected, values=names, state="readonly", width=70).pack(
            padx=12, fill="x"
        )
        source_options = {"Автоматически определить источник": None}
        source_options.update(
            {
                f'{s["file"]} / {s["sheet"]} [{s["id"]}]': s["id"]
                for s in self.project.get("imports", [])
            }
        )
        source = tk.StringVar(value=next(iter(source_options)))
        ttk.Label(
            dialog,
            text="Если файл переименован или перенесён, выберите прежний источник:",
            padding=10,
        ).pack(anchor="w")
        ttk.Combobox(
            dialog, textvariable=source, values=list(source_options), state="readonly", width=70
        ).pack(padx=12, fill="x")
        basis = tk.StringVar(value="Мощность уже суммарная для строки")
        ttk.Label(dialog, text="Для выгрузки «Количество / шт.»:", padding=10).pack(anchor="w")
        ttk.Combobox(
            dialog,
            textvariable=basis,
            values=["Мощность уже суммарная для строки", "Мощность одного прибора × количество"],
            state="readonly",
        ).pack(fill="x", padx=12)
        report_frame = ttk.Frame(dialog)
        report_frame.pack(fill="both", expand=True, padx=12, pady=10)
        report = tk.Text(report_frame, wrap="word", height=15)
        self.scroll_text(report, report_frame)
        staged = {}
        apply_button = None

        def invalidate(*args):
            staged.clear()
            if apply_button is not None:
                apply_button.config(state="disabled")

        def preview():
            invalidate()
            try:
                project, warnings = import_table(
                    self.project,
                    path,
                    selected.get(),
                    source_id=source_options[source.get()],
                    heat_basis=(
                        "row_total" if basis.get().startswith("Мощность уже") else "per_item"
                    ),
                )
                old_ids = {s["id"] for s in self.project["segments"]}
                new_ids = {s["id"] for s in project["segments"]}
                text = (
                    f'После импорта: веток {len(project["branches"])}, участков {len(project["segments"])}.\n'
                    f"Новых участков: {len(new_ids-old_ids)}; удалённых из снимка: {len(old_ids-new_ids)}.\n"
                    f'Суммарная длина подводок: {sum(number(s["length_m"],"Длина") for s in project["segments"]):.3f} м.\n\n'
                    + "\n".join(warnings)
                )
                self.set_text(report, text)
                staged["project"] = project
                apply_button.config(state="normal")
            except Exception as e:
                self.set_text(report, "Импорт не выполнен. " + str(e))

        def apply():
            if "project" not in staged:
                return
            self.apply_project(staged["project"])
            dialog.destroy()
            self.check()
            self.status.set(
                "Импорт применён. Доступна отмена. Проверьте мощность, диаметры и сопротивления."
            )

        buttons = ttk.Frame(dialog, padding=10)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Проверить файл", command=preview).pack(side="left", padx=4)
        apply_button = ttk.Button(buttons, text="Применить импорт", command=apply, state="disabled")
        apply_button.pack(side="left", padx=4)
        ttk.Button(buttons, text="Отмена", command=dialog.destroy).pack(side="right")
        for var in (selected, source, basis):
            var.trace_add("write", invalidate)

    def template(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx", initialfile="Шаблон веток.xlsx"
        )
        if path:
            create_template(path)
            self.status.set("Шаблон сохранён: " + path)

    def run(self):
        try:
            self.result = calculate(self.project)
        except (ValueError, KeyError, TypeError) as e:
            self.result = None
            self.result_tree.delete(*self.result_tree.get_children())
            self.details_tree.delete(*self.details_tree.get_children())
            self.collector_tree.delete(*self.collector_tree.get_children())
            self.set_text(self.summary, "Расчёт не выполнен.")
            self.check()
            self.issue_tree.insert("", "end", values=["Расчёт остановлен", "Расчёт", str(e)])
            self.set_text(self.notes, str(e))
            self.status.set("Расчёт не выполнен: откройте «Проверка».")
            return
        self.result_tree.delete(*self.result_tree.get_children())
        for r in self.result["branches"]:
            self.result_tree.insert(
                "",
                "end",
                values=[
                    r["id"],
                    r["system_id"],
                    r["collector_id"],
                    f'{r["length_m"]:.3f}',
                    f'{r["flow_m3h"]:.4f}',
                    f'{r["max_velocity_ms"]:.3f}',
                    f'{r["branch_dp_pa"]:.1f}',
                    f'{r["main_dp_pa"]:.1f}',
                    f'{r["loop_dp_pa"]:.1f}',
                    "—" if r.get("balance_dp_pa") is None else f'{r["balance_dp_pa"]:.1f}',
                    "Да" if r["path_complete"] else "Не подтверждена",
                ],
            )
        self.details_tree.delete(*self.details_tree.get_children())
        for row in self.result["segments"] + self.result["mains"]:
            values = []
            for key in self.details_tree["columns"]:
                value = row.get(key, row.get("system_id", "") if key == "branch_id" else "")
                values.append(f"{value:.6g}" if isinstance(value, float) else value)
            self.details_tree.insert("", "end", values=values)
        self.collector_tree.delete(*self.collector_tree.get_children())
        for row in self.result["collectors"]:
            self.collector_tree.insert(
                "",
                "end",
                values=[
                    f"{row[k]:.4g}" if isinstance(row[k], float) else row[k]
                    for k in self.collector_tree["columns"]
                ],
            )
        lines = []
        for s in self.result["systems"]:
            line = f'Система {s["id"]}: нагрузка {s["heat_w"]/1000:.2f} кВт; расход {s["flow_m3h"]:.3f} м³/ч. '
            if s["complete"]:
                line += f'Диктующие кольца: {", ".join(s["critical_loop_ids"])}. Потери {s["max_calculated_dp_pa"]:.0f} Па; напор {s["head_m"]:.2f} м жидкости.'
                if s["head_with_margin_m"] is not None:
                    line += f'\nС запасами и пересчётом потерь: {s["flow_with_margin_m3h"]:.3f} м³/ч и {s["head_with_margin_m"]:.2f} м.'
                else:
                    line += "\nНапор при увеличенном расходе не определён: неизвестен закон дополнительных потерь."
            else:
                line += f'Максимум учтённых путей: {s["candidate_loop_id"]}. Полный напор пока не определён.'
            line += f' Самая мощная ветка: {s["most_loaded_branch_id"]}.'
            lines.append(line)
        self.set_text(self.summary, "\n\n".join(lines) or "Нет веток для расчёта.")
        self.set_text(
            self.notes,
            "\n".join(self.result["warnings"])
            or "Расчёт выполнен по введённым исходным данным. Полнота схемы подтверждается пользователем.",
        )
        self.tabs.select(self.output)
        self.status.set("Расчёт завершён. Детали доступны на вкладке «По участкам» и в Excel.")

    @staticmethod
    def scroll_text(widget, parent, expand=True):
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=widget.yview)
        scrollbar.pack(side="right", fill="y")
        widget.configure(yscrollcommand=scrollbar.set)
        widget.pack(side="left", fill="both", expand=True)

    @staticmethod
    def set_text(widget, value):
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", value)
        widget.config(state="disabled")

    def export(self):
        if self.result is None:
            messagebox.showinfo("Экспорт", "Сначала выполните расчёт.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx", initialfile="Гидравлика — результаты.xlsx"
        )
        if path:
            export_results(self.result, path)
            self.status.set("Результаты сохранены: " + path)

    def close(self):
        if self.can_replace():
            try:
                self.autosave_path.unlink(missing_ok=True)
                self.autosave_path.with_name(self.autosave_path.name + ".bak").unlink(
                    missing_ok=True
                )
            except OSError:
                pass
            self.destroy()


if __name__ == "__main__":
    app = App()
    if len(sys.argv) > 1:
        try:
            app.project = load_project(sys.argv[1])
            app.path = sys.argv[1]
            app.disk_digest = file_digest(app.path)
            app.refresh()
        except (OSError, ValueError) as e:
            messagebox.showerror("Проект", str(e))
    app.mainloop()
