"""Design-flow hydraulic calculation, SI internally. No Revit or Excel execution."""

from __future__ import annotations
import copy
import hashlib
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

G = 9.80665
VERSION = 1
APP_VERSION = "0.2"


class InputError(ValueError):
    pass


def number(value, label, minimum=0, positive=False, maximum=1e12):
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise InputError(f"{label}: требуется число.")
    try:
        result = float(
            str(value)
            .strip()
            .replace("\u00a0", "")
            .replace("\u202f", "")
            .replace(" ", "")
            .replace(",", ".")
        )
    except (ValueError, TypeError, OverflowError):
        raise InputError(f"{label}: требуется число.") from None
    if (
        not math.isfinite(result)
        or result < minimum
        or result > maximum
        or (positive and result <= 0)
    ):
        raise InputError(
            f"{label}: недопустимое значение {value} (пределы {minimum:g}…{maximum:g})."
        )
    return result


def identifier(value, label):
    if (
        not isinstance(value, str)
        or not value.strip()
        or value != value.strip()
        or len(value) > 250
    ):
        raise InputError(
            f"{label}: нужна непустая строка ID без пробелов по краям, до 250 символов."
        )
    if any(ord(c) < 32 for c in value):
        raise InputError(f"{label}: ID содержит управляющие символы.")
    return value


def water_properties(temperature):
    table = [
        (5, 1000, 4202, 1.522),
        (10, 999.59, 4192, 1.309),
        (20, 998.2, 4182, 1.004),
        (30, 995.7, 4178, 0.801),
        (40, 992.2, 4179, 0.658),
        (50, 988, 4181, 0.553),
        (60, 983.24, 4185, 0.475),
        (70, 977.81, 4190, 0.4132),
        (80, 971.8, 4196, 0.365),
        (90, 965.3, 4205, 0.326),
        (95, 961.9, 4211, 0.310),
    ]
    t = number(temperature, "Средняя температура для свойств воды", minimum=5, maximum=95)
    for low, high in zip(table, table[1:]):
        if low[0] <= t <= high[0]:
            ratio = (t - low[0]) / (high[0] - low[0])
            return dict(
                zip(
                    ("rho", "cp", "nu_mm2_s"),
                    [a + (b - a) * ratio for a, b in zip(low[1:], high[1:])],
                )
            )
    raise InputError("Температура вне справочника воды 5–95 °C.")


def effective_system(system):
    """Legacy projects without properties_mode retain explicit properties."""
    s = copy.deepcopy(system)
    supply = number(s.get("supply_c"), "Подача, °C", minimum=-100, maximum=300)
    ret = number(s.get("return_c"), "Обратка, °C", minimum=-100, maximum=300)
    if supply <= ret or supply - ret < 0.1:
        raise InputError(
            f'Система {s.get("id", "")}: разность подачи и обратки должна быть ≥ 0,1 °C.'
        )
    mode = s.get("properties_mode", "manual")
    if mode not in ("manual", "water_auto"):
        raise InputError("Режим свойств: water_auto (вода) или manual (вручную).")
    if mode == "water_auto":
        s.update(water_properties((supply + ret) / 2))
        s["coolant"] = "Вода"
    for field, low, high in [("rho", 100, 3000), ("cp", 100, 10000), ("nu_mm2_s", 0.05, 1000)]:
        s[field] = number(s.get(field), f'{s.get("id", "")} / {field}', minimum=low, maximum=high)
    for field in ("flow_margin_percent", "head_margin_percent"):
        s[field] = number(s.get(field, 0), field, maximum=100)
    s["velocity_limit_ms"] = number(
        s.get("velocity_limit_ms", 1), "Контроль скорости, м/с", minimum=0.01, maximum=20
    )
    s.update(supply_c=supply, return_c=ret)
    return s


def default_system(identifier="1.1"):
    return {
        "id": identifier,
        "name": "Радиаторное отопление",
        "supply_c": 80,
        "return_c": 60,
        "coolant": "Вода",
        "properties_mode": "water_auto",
        **water_properties(70),
        "flow_margin_percent": 0,
        "head_margin_percent": 0,
        "velocity_limit_ms": 1,
    }


def empty_project():
    return {
        "schema_version": VERSION,
        "name": "Новый проект",
        "systems": [default_system()],
        "branches": [],
        "segments": [],
        "mains": [],
    }


def unique_rows(rows, label):
    if not isinstance(rows, list) or len(rows) > 100000:
        raise InputError(f"{label}: требуется список, не более 100000 записей.")
    result = {}
    for row in rows:
        if not isinstance(row, dict):
            raise InputError(f"{label}: некорректная запись.")
        key = identifier(row.get("id"), label)
        if key in result:
            raise InputError(f"{label}: повторяющийся ID «{key}».")
        result[key] = row
    return result


def validate_segment(seg, draft=True):
    label = seg.get("id", "Участок")
    values = {}
    for key, default, maximum in [
        ("length_m", None, 100000),
        ("inner_mm", None, 3000),
        ("roughness_mm", 0.007, 100),
        ("zeta", 0, 1e6),
        ("extra_dp_pa", 0, 1e9),
    ]:
        values[key] = number(seg.get(key, default), f"{label} / {key}", maximum=maximum)
    d = values["inner_mm"]
    if d and d < 0.1:
        raise InputError(f"{label}: внутренний диаметр должен быть ≥ 0,1 мм.")
    if not d and not draft:
        raise InputError(f"{label}: заполните внутренний диаметр.")
    if d and values["roughness_mm"] >= d:
        raise InputError(f"{label}: шероховатость должна быть меньше диаметра.")
    kv = seg.get("kv_m3h")
    if kv not in (None, ""):
        number(kv, f"{label} / Kv", minimum=1e-6, maximum=1e6)
    if seg.get("extra_model", "design") not in ("design", "quadratic"):
        raise InputError(f"{label}: закон доп. потерь должен быть design или quadratic.")
    return values


def validate_project(project):
    """Validate a saveable draft. Zero heat/diameter are placeholders, never a valid calculation."""
    if (
        not isinstance(project, dict)
        or type(project.get("schema_version")) is not int
        or project["schema_version"] != VERSION
    ):
        raise InputError("Неподдерживаемый формат проекта.")
    if not isinstance(project.get("name"), str):
        raise InputError("Название проекта должно быть текстом.")
    maps = {
        key: unique_rows(project.get(key), key)
        for key in ("systems", "branches", "segments", "mains")
    }
    for key in maps:
        for row in maps[key].values():
            if "name" in row and not isinstance(row["name"], str):
                raise InputError(f'{row["id"]}: название должно быть текстом.')
            for meta in ("source", "revit", "_import"):
                if meta in row and not isinstance(row[meta], dict):
                    raise InputError(f'{row["id"]}: {meta} должен быть объектом JSON.')
    if "imports" in project:
        if not isinstance(project["imports"], list):
            raise InputError("imports должен быть списком.")
        for source in project["imports"]:
            if not isinstance(source, dict) or not isinstance(source.get("powers", {}), dict):
                raise InputError("Некорректная запись источника импорта.")
            identifier(source.get("id"), "ID источника импорта")
    for s in maps["systems"].values():
        effective_system(s)
    for b in maps["branches"].values():
        sid = identifier(b.get("system_id"), f'{b["id"]} / система')
        if sid not in maps["systems"]:
            raise InputError(f'Ветка {b["id"]}: неизвестная система.')
        identifier(b.get("collector_id"), f'{b["id"]} / коллектор')
        number(b.get("heat_w", 0), f'{b["id"]} / мощность', maximum=1e9)
        path = b.get("main_path", [])
        if not isinstance(path, list):
            raise InputError(f'{b["id"]}: маршрут должен быть списком ID.')
        for mid in path:
            identifier(mid, f'{b["id"]} / магистраль')
        if len(path) != len(set(path)):
            raise InputError(f'{b["id"]}: магистраль повторяется в маршруте.')
        if type(b.get("path_complete", False)) is not bool:
            raise InputError(f'{b["id"]}: полнота должна быть true/false.')
        for mid in path:
            if mid not in maps["mains"] or maps["mains"][mid].get("system_id") != sid:
                raise InputError(
                    f'{b["id"]}: магистраль {mid} отсутствует или относится к другой системе.'
                )
    for seg in maps["segments"].values():
        if identifier(seg.get("branch_id"), f'{seg["id"]} / ветка') not in maps["branches"]:
            raise InputError(f'{seg["id"]}: неизвестная ветка.')
        validate_segment(seg)
    for main in maps["mains"].values():
        if identifier(main.get("system_id"), f'{main["id"]} / система') not in maps["systems"]:
            raise InputError(f'{main["id"]}: неизвестная система.')
        validate_segment(main)
    # All metadata must also be valid JSON, including values not used by the engine.
    try:
        json.dumps(project, allow_nan=False)
    except (ValueError, TypeError, OverflowError, RecursionError) as e:
        raise InputError(f"Некорректные метаданные проекта: {e}") from None
    return maps


def readiness(project):
    """Return all missing engineering inputs together, instead of failing one row at a time."""
    issues = []
    try:
        maps = validate_project(project)
    except InputError as e:
        return [{"severity": "error", "id": "Проект", "message": str(e)}]

    def issue(level, rid, msg):
        issues.append({"severity": level, "id": rid, "message": msg})

    segments_by_branch = {bid: [] for bid in maps["branches"]}
    for seg in maps["segments"].values():
        segments_by_branch[seg["branch_id"]].append(seg)
    if not maps["branches"]:
        issue("error", "Проект", "Нет веток для расчёта.")
    for bid, b in maps["branches"].items():
        if number(b.get("heat_w", 0), bid) < 0.01:
            issue("error", bid, "Не задана расчётная мощность ≥ 0,01 Вт.")
        if not segments_by_branch[bid]:
            issue("error", bid, "Нет участков подводки.")
        if not b.get("path_complete"):
            issue("warning", bid, "Полнота кольца не подтверждена; окончательный напор недоступен.")
    for key in ("segments", "mains"):
        for sid, s in maps[key].items():
            if not number(s["inner_mm"], sid):
                issue("error", sid, "Не задан внутренний диаметр, мм.")
            if not any(number(s.get(k, 0) or 0, k) > 0 for k in ("zeta", "kv_m3h", "extra_dp_pa")):
                issue(
                    "warning",
                    sid,
                    "Учтено только трение труб; проверьте сопротивления арматуры и приборов.",
                )
    for mid, m in maps["mains"].items():
        if not any(mid in b.get("main_path", []) for b in maps["branches"].values()):
            issue(
                "warning",
                mid,
                "Магистраль не входит ни в один маршрут; полнота системы требует проверки.",
            )
    return issues


def segment_loss(segment, mass_kg_s, system, flow_factor=1):
    vals = validate_segment(segment, draft=False)
    label = segment.get("id", "Участок")
    length = vals["length_m"]
    d = vals["inner_mm"] / 1000
    rough = vals["roughness_mm"] / 1000
    zeta = vals["zeta"]
    extra = vals["extra_dp_pa"]
    kv_value = segment.get("kv_m3h")
    kv = None if kv_value in (None, "") else number(kv_value, label + " / Kv", positive=True)
    rho = number(system["rho"], "Плотность", minimum=100, maximum=3000)
    nu = number(system["nu_mm2_s"], "Вязкость", minimum=0.05, maximum=1000) * 1e-6
    mass = number(mass_kg_s, "Массовый расход", maximum=1e7)
    if 0 < mass < 1e-12:
        raise InputError(f"{label}: расход меньше диапазона расчёта 1e-12 кг/с.")
    factor = number(flow_factor, "Множитель расхода", positive=True, maximum=2)
    volume = mass / rho
    velocity = volume / (math.pi * d * d / 4)
    re = velocity * d / nu
    if velocity > 100 or re > 1e10:
        raise InputError(
            f"{label}: расход и диаметр дают v={velocity:.3g} м/с. Проверьте единицы и исходные данные."
        )
    if re == 0:
        friction = 0.0
        regime = "Нет расхода"
    elif re < 2300:
        friction = 64 / re
        regime = "Ламинарный"
    else:
        a = (2.457 * math.log(1 / ((7 / re) ** 0.9 + 0.27 * rough / d))) ** 16
        b = (37530 / re) ** 16
        friction = 8 * ((8 / re) ** 12 + 1 / (a + b) ** 1.5) ** (1 / 12)
        regime = "Переходный" if re < 4000 else "Турбулентный"
    dynamic = rho * velocity * velocity / 2
    r = friction / d * dynamic
    dp_linear = r * length
    dp_local = zeta * dynamic
    dp_kv = (volume * 3600 / kv) ** 2 * (rho / 1000) * 100000 if kv else 0.0
    model = segment.get("extra_model", "design")
    if extra and factor != 1 and model == "design":
        raise InputError(
            f"{label}: доп. потери заданы только при проектном расходе; закон при увеличении расхода неизвестен."
        )
    dp_extra = extra * (factor**2 if model == "quadratic" else 1) if mass else 0.0
    return {
        "id": label,
        "length_m": length,
        "inner_mm": d * 1000,
        "flow_m3h": volume * 3600,
        "mass_kgh": mass * 3600,
        "velocity_ms": velocity,
        "re": re,
        "lambda": friction,
        "regime": regime,
        "r_pa_m": r,
        "dp_linear_pa": dp_linear,
        "dp_local_pa": dp_local,
        "dp_kv_pa": dp_kv,
        "dp_extra_pa": dp_extra,
        "dp_pa": dp_linear + dp_local + dp_kv + dp_extra,
        "source": copy.deepcopy(segment.get("source", {})),
    }


def project_hash(project):
    return hashlib.sha256(
        json.dumps(project, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()


def calculate(project):
    maps = validate_project(project)
    issues = readiness(project)
    errors = [f'{x["id"]}: {x["message"]}' for x in issues if x["severity"] == "error"]
    if errors:
        raise InputError("Не заполнены исходные данные:\n" + "\n".join(errors))
    systems = {sid: effective_system(s) for sid, s in maps["systems"].items()}
    result = {
        "branches": [],
        "segments": [],
        "mains": [],
        "systems": [],
        "collectors": [],
        "warnings": [f'{x["id"]}: {x["message"]}' for x in issues if x["severity"] == "warning"],
        "metadata": {
            "app_version": APP_VERSION,
            "calculated_utc": datetime.now(timezone.utc).isoformat(),
            "project_sha256": project_hash(project),
        },
        "inputs": copy.deepcopy(project),
    }
    masses = {}
    segments_by_branch = {bid: [] for bid in maps["branches"]}
    for seg in maps["segments"].values():
        segments_by_branch[seg["branch_id"]].append(seg)
    for bid, b in maps["branches"].items():
        s = systems[b["system_id"]]
        masses[bid] = number(b["heat_w"], bid) / (s["cp"] * (s["supply_c"] - s["return_c"]))
    main_users = {
        mid: [bid for bid, b in maps["branches"].items() if mid in b.get("main_path", [])]
        for mid in maps["mains"]
    }

    def network(sid, factor):
        s = systems[sid]
        bs = {}
        ss = []
        ms = {}
        for bid, b in maps["branches"].items():
            if b["system_id"] != sid:
                continue
            rows = [
                dict(segment_loss(seg, masses[bid] * factor, s, factor), branch_id=bid)
                for seg in segments_by_branch[bid]
            ]
            ss.extend(rows)
            bs[bid] = {
                "id": bid,
                "name": b.get("name", ""),
                "system_id": sid,
                "collector_id": b["collector_id"],
                "heat_w": number(b["heat_w"], bid),
                "mass_kgh": masses[bid] * factor * 3600,
                "flow_m3h": masses[bid] * factor / s["rho"] * 3600,
                "length_m": math.fsum(x["length_m"] for x in rows),
                "max_velocity_ms": max(x["velocity_ms"] for x in rows),
                "branch_dp_pa": math.fsum(x["dp_pa"] for x in rows),
                "path_complete": b.get("path_complete", False),
                "main_path": b.get("main_path", []),
            }
        for mid, m in maps["mains"].items():
            if m["system_id"] == sid:
                users = main_users[mid]
                mass = math.fsum(masses[b] for b in users) * factor
                ms[mid] = dict(segment_loss(m, mass, s, factor), system_id=sid, branch_ids=users)
        for bid, b in bs.items():
            b["main_dp_pa"] = math.fsum(ms[mid]["dp_pa"] for mid in b["main_path"])
            b["loop_dp_pa"] = b["branch_dp_pa"] + b["main_dp_pa"]
        return bs, ss, ms

    for sid, s in systems.items():
        bs, ss, ms = network(sid, 1)
        if not bs:
            continue
        result["segments"].extend(ss)
        result["mains"].extend(ms.values())
        complete = all(b["path_complete"] for b in bs.values()) and all(
            main_users[mid] for mid in ms
        )
        maximum = max(b["loop_dp_pa"] for b in bs.values())
        critical = [
            b["id"]
            for b in bs.values()
            if math.isclose(b["loop_dp_pa"], maximum, rel_tol=1e-9, abs_tol=1e-6)
        ]
        for b in bs.values():
            b["balance_dp_pa"] = max(0, maximum - b["loop_dp_pa"]) if complete else None
            result["branches"].append(b)
        factor = 1 + s["flow_margin_percent"] / 100
        margin_error = ""
        margin_dp = None
        margin_critical = []
        try:
            margin_bs, _, _ = network(sid, factor) if factor != 1 else (bs, ss, ms)
            margin_dp = max(b["loop_dp_pa"] for b in margin_bs.values())
            margin_critical = [
                b["id"]
                for b in margin_bs.values()
                if math.isclose(b["loop_dp_pa"], margin_dp, rel_tol=1e-9, abs_tol=1e-6)
            ]
        except InputError as e:
            margin_error = str(e)
            result["warnings"].append(f"Система {sid}, запас расхода: {e}")
        flow = math.fsum(b["flow_m3h"] for b in bs.values())
        head = maximum / (s["rho"] * G)
        result["systems"].append(
            {
                "id": sid,
                "heat_w": math.fsum(b["heat_w"] for b in bs.values()),
                "flow_m3h": flow,
                "max_branch_id": max(bs.values(), key=lambda b: b["branch_dp_pa"])["id"],
                "most_loaded_branch_id": max(bs.values(), key=lambda b: b["heat_w"])["id"],
                "candidate_loop_id": critical[0],
                "critical_loop_id": critical[0] if complete else None,
                "critical_loop_ids": critical if complete else [],
                "complete": complete,
                "max_calculated_dp_pa": maximum,
                "head_m": head if complete else None,
                "flow_with_margin_m3h": flow * factor,
                "dp_at_increased_flow_pa": margin_dp,
                "margin_critical_loop_ids": margin_critical,
                "head_with_margin_m": (
                    margin_dp / (s["rho"] * G) * (1 + s["head_margin_percent"] / 100)
                    if complete and margin_dp is not None
                    else None
                ),
                "margin_status": margin_error or ("Рассчитано" if complete else "Неполная схема"),
                "rho": s["rho"],
                "cp": s["cp"],
                "nu_mm2_s": s["nu_mm2_s"],
                "supply_c": s["supply_c"],
                "return_c": s["return_c"],
                "properties_mode": s.get("properties_mode", "manual"),
            }
        )
        for row in ss + list(ms.values()):
            if row["regime"] == "Переходный":
                result["warnings"].append(f'{row["id"]}: переходный режим, Re={row["re"]:.0f}.')
            if row["velocity_ms"] > s["velocity_limit_ms"]:
                result["warnings"].append(
                    f'{row["id"]}: v={row["velocity_ms"]:.2f} м/с превышает заданный контроль {s["velocity_limit_ms"]:g} м/с.'
                )
        for cid in sorted({b["collector_id"] for b in bs.values()}):
            cb = [b for b in bs.values() if b["collector_id"] == cid]
            result["collectors"].append(
                {
                    "system_id": sid,
                    "collector_id": cid,
                    "branch_count": len(cb),
                    "heat_w": math.fsum(b["heat_w"] for b in cb),
                    "flow_m3h": math.fsum(b["flow_m3h"] for b in cb),
                    "length_m": math.fsum(b["length_m"] for b in cb),
                    "max_branch_dp_pa": max(b["branch_dp_pa"] for b in cb),
                }
            )
        if not complete:
            result["warnings"].append(
                f"Система {sid}: полный напор насоса не определён; проверьте пути, потребителей и сопротивления."
            )
    return result


def file_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest() if Path(path).exists() else None


def atomic_bytes(path, data, backup=True):
    path = Path(path)
    fd, temp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if backup and path.exists():
            atomic_bytes(path.with_name(path.name + ".bak"), path.read_bytes(), backup=False)
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def save_project(project, path, expected_digest="unchecked"):
    validate_project(project)
    if expected_digest != "unchecked" and file_digest(path) != expected_digest:
        raise InputError(
            "Файл изменён другой программой. Откройте его заново или сохраните проект под другим именем."
        )
    data = json.dumps(project, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")
    if len(data) > 30 * 1024 * 1024:
        raise InputError(
            "Проект превышает 30 МБ. Разделите независимые насосные системы на отдельные проекты."
        )
    atomic_bytes(path, data)


def load_project(path):
    path = Path(path)
    if path.stat().st_size > 30 * 1024 * 1024:
        raise InputError("Проект превышает 30 МБ.")

    def pairs(items):
        result = {}
        for k, v in items:
            if k in result:
                raise InputError(f"Повтор ключа JSON: {k}.")
            result[k] = v
        return result

    def constant(value):
        raise InputError(f"Недопустимое число JSON: {value}.")

    try:
        project = json.loads(
            path.read_text(encoding="utf-8-sig"), object_pairs_hook=pairs, parse_constant=constant
        )
    except (RecursionError, UnicodeError) as e:
        raise InputError(f"Некорректный JSON: {e}") from None
    validate_project(project)
    return project


def demo_project():
    p = empty_project()
    p["name"] = "Пример — две ветки и общая магистраль"
    for n, heat, length in [(1, 1000, 20), (2, 1500, 35)]:
        bid = f"101-{n}"
        p["branches"].append(
            {
                "id": bid,
                "system_id": "1.1",
                "collector_id": "101",
                "name": f"Радиатор {n}",
                "heat_w": heat,
                "main_path": ["M-подача", "M-обратка"],
                "path_complete": True,
            }
        )
        p["segments"].append(
            {
                "id": f"{bid}-трубы",
                "branch_id": bid,
                "length_m": length,
                "inner_mm": 11.6,
                "roughness_mm": 0.007,
                "zeta": 8,
                "kv_m3h": None,
                "extra_dp_pa": 0,
            }
        )
    for leg in ("подача", "обратка"):
        p["mains"].append(
            {
                "id": "M-" + leg,
                "system_id": "1.1",
                "name": leg,
                "length_m": 10,
                "inner_mm": 20,
                "roughness_mm": 0.007,
                "zeta": 3,
                "kv_m3h": None,
                "extra_dp_pa": 0,
            }
        )
    return p
