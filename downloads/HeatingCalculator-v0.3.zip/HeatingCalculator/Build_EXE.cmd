@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run Install.cmd first.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-build.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m unittest discover -s tests -q
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --onedir --name HeatingCalculator --add-data "README.md;." launcher.py
if errorlevel 1 goto failed
echo Ready: dist\HeatingCalculator\HeatingCalculator.exe
echo Copy the WHOLE dist\HeatingCalculator folder to another Windows PC.
pause
exit /b 0
:failed
echo Build failed. Read the message above.
pause
exit /b 1
