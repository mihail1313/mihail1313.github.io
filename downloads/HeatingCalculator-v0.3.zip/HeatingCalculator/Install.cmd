@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys,tkinter; assert (3,11)<=sys.version_info[:2]<=(3,14)" >nul 2>nul
  if not errorlevel 1 goto use_py
)
if exist "%USERPROFILE%\Revit-Codex\.venv\Scripts\python.exe" (
  "%USERPROFILE%\Revit-Codex\.venv\Scripts\python.exe" -c "import sys,tkinter; assert (3,11)<=sys.version_info[:2]<=(3,14)" >nul 2>nul
  if not errorlevel 1 goto use_codex_python
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys,tkinter; assert (3,11)<=sys.version_info[:2]<=(3,14)" >nul 2>nul
  if not errorlevel 1 goto use_python
)
echo Python 3.11-3.14 with Tcl/Tk was not found. Install Python from python.org.
pause
exit /b 1
:use_py
py -3 setup_app.py
goto done
:use_codex_python
"%USERPROFILE%\Revit-Codex\.venv\Scripts\python.exe" setup_app.py
goto done
:use_python
python setup_app.py
:done
set "HEATING_SETUP_EXIT=%ERRORLEVEL%"
if not "%HEATING_SETUP_EXIT%"=="0" echo Installation failed. See install.log. You can run Install.cmd again.
pause
exit /b %HEATING_SETUP_EXIT%
