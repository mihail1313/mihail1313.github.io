"""Auditable Excel/CSV snapshots. No formula execution; transactional import."""

from __future__ import annotations
import copy, csv, hashlib, io, json, math, re
from pathlib import Path
from hydraulics import InputError, default_system, number, validate_project, readiness, atomic_bytes

MAX_ROWS = 50000
MAX_COLUMNS = 200


class CellProblem(str):
    pass


def text(value):
    if value is None:
        return ""
    if isinstance(value, float):
        return format(value, ".15g")
    return str(value).strip()


def norm(value):
    return re.sub(r"[^a-zа-я0-9]", "", text(value).lower().replace("ё", "е"))


def read_rows(path, sheet=None):
    path = Path(path)
    if path.stat().st_size > 40 * 1024 * 1024:
        raise InputError("Файл превышает 40 МБ. Выгрузите отдельную ведомость.")
    if path.suffix.lower() in (".csv", ".txt", ".tsv"):
        raw = path.read_bytes()
        if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
            data = raw.decode("utf-16")
        else:
            try:
                data = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                data = raw.decode("cp1251")
        first = data.splitlines()[0] if data else ""
        # Revit uses tabs; Russian decimal commas must not become separators.
        if "\t" in first:
            dialect = csv.excel_tab
        elif ";" in first:
            dialect = type("SemicolonDialect", (csv.excel,), {"delimiter": ";"})
        else:
            try:
                dialect = csv.Sniffer().sniff(data[:8192], delimiters=",")
            except csv.Error:
                dialect = csv.excel
        rows = []
        for row in csv.reader(io.StringIO(data, newline=""), dialect):
            if len(rows) >= MAX_ROWS or len(row) > MAX_COLUMNS:
                raise InputError("Ведомость превышает 50000 строк / 200 колонок.")
            rows.append(row)
        return rows, "CSV"
    if path.suffix.lower() != ".xlsx":
        raise InputError("Поддерживаются XLSX, CSV, TSV и текстовые ведомости Revit.")
    import openpyxl

    cached = openpyxl.load_workbook(path, data_only=True, read_only=True)
    try:
        formulas = openpyxl.load_workbook(path, data_only=False, read_only=True)
        try:
            name = sheet or cached.sheetnames[0]
            if name not in cached.sheetnames:
                raise InputError(f"Нет листа «{name}».")
            s = cached[name]
            f = formulas[name]
            if (s.max_row or 0) > MAX_ROWS or (s.max_column or 0) > MAX_COLUMNS:
                raise InputError(
                    "Лист превышает 50000 строк / 200 колонок. Скопируйте исходную таблицу на отдельный лист."
                )
            rows = []
            for cr, fr in zip(s.iter_rows(), f.iter_rows()):
                row = []
                for c, fc in zip(cr, fr):
                    value = c.value
                    if c.data_type == "e":
                        value = CellProblem(f"Ошибка Excel {c.value} в {c.coordinate}")
                    elif fc.data_type == "f" and value is None:
                        value = CellProblem(
                            f"Формула {fc.coordinate} не имеет сохранённого результата. Пересчитайте и сохраните книгу в Excel."
                        )
                    row.append(value)
                rows.append(row)
            return rows, name
        finally:
            formulas.close()
    finally:
        cached.close()


def sheet_names(path):
    if Path(path).suffix.lower() in (".csv", ".txt", ".tsv"):
        return ["CSV"]
    import openpyxl

    w = openpyxl.load_workbook(path, read_only=True)
    try:
        return w.sheetnames
    finally:
        w.close()


def import_table(project, path, sheet=None, source_id=None, heat_basis="row_total"):
    """Snapshot replacement is scoped to one source. Input project is never mutated.
    Explicit segment/element IDs survive value edits. Without IDs, identical row content
    survives reordering, but a changed row is NEW; manual values are never guessed across it.
    """
    if heat_basis not in ("row_total", "per_item"):
        raise InputError("Мощность: row_total или per_item.")
    validate_project(project)
    rows, sheet = read_rows(path, sheet)
    header_index = None
    for i, row in enumerate(rows[:50]):
        if any("номерветки" in norm(v) or norm(v) == "branchid" for v in row):
            header_index = i
            break
    if header_index is None:
        raise InputError("Не найден заголовок «Номер ветки». Выберите исходную ведомость.")
    header = [norm(v) for v in rows[header_index]]

    def col(exact=(), contains=()):
        matches = [i for i, h in enumerate(header) if h in exact or any(s in h for s in contains)]
        if len(matches) > 1:
            raise InputError(
                f'Неоднозначные колонки: {", ".join(text(rows[header_index][i]) for i in matches)}. Оставьте одну.'
            )
        return matches[0] if matches else None

    fields = {
        "branch": col(("branchid",), ("номерветки",)),
        "system": col(("systemid",), ("номерсистемы",)),
        "collector": col(("collectorid",), ("номерколлектора",)),
        "name": col(("name", "наименование"), ("наименованиемарка",)),
        "length": col(
            (
                "lengthm",
                "lengthmm",
                "длинам",
                "длина",
                "длинатрубм",
                "длинамм",
                "длинатрубмм",
                "длинатруб",
            )
        ),
        "inner": col(
            ("innermm", "innerm", "внутреннийдиаметрмм", "внутреннийдиаметр", "внутреннийдиаметрм")
        ),
        "nominal": col(("диаметр", "диаметртрубмм", "диаметрмм")),
        "quantity": col(("количество",)),
        "unit": col(("единицаизмерения", "едизм")),
        "manual_heat": col((), ("qвтвводвручную",)),
        "heat": col(
            (
                "heatw",
                "heatkw",
                "мощностьвт",
                "мощностьквт",
                "расчетнаямощностьвт",
                "расчетнаямощностьквт",
                "qвт",
                "qквт",
            ),
            ("qвтрасчетвсемействе",),
        ),
        "zeta": col(("zeta", "кмс", "суммакмс")),
        "roughness": col(("roughnessmm", "шероховатостьмм")),
        "kv": col(("kvm3h", "kv")),
        "extra": col(("extradppa", "доппотерипа", "доппотерикпа")),
        "category": col(("категория",)),
        "row_id": col(("segmentid", "idучастка", "uniqueid", "elementid", "idэлемента")),
        "extra_model": col(("extramodel", "закондоппотерь")),
    }
    for field, fragment in [("length", "длина"), ("inner", "внутреннийдиаметр")]:
        if fields[field] is None and any(fragment in h for h in header):
            raise InputError(
                f"Не распознаны единицы колонки «{fragment}». Используйте заголовки шаблона: м / мм."
            )
    target = copy.deepcopy(project)
    warnings = []
    sources = target.setdefault("imports", [])
    if not isinstance(sources, list):
        raise InputError("Некорректный журнал imports в проекте.")
    filepath = str(Path(path).resolve())
    digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if source_id is not None:
        previous = next((s for s in sources if s.get("id") == source_id), None)
        if previous is None:
            raise InputError("Не найден источник для обновления.")
    else:
        candidates = [
            s
            for s in sources
            if s.get("sheet") == sheet and (s.get("path") == filepath or s.get("sha256") == digest)
        ]
        previous = candidates[0] if len(candidates) == 1 else None
    batch = (
        previous["id"]
        if previous
        else hashlib.sha256((filepath + "|" + sheet).encode()).hexdigest()[:16]
    )
    legacy = "X-" + hashlib.sha256((filepath + "|" + sheet).encode()).hexdigest()[:10] + "-"
    if any(str(s["id"]).startswith(legacy) and not s.get("_import") for s in target["segments"]):
        raise InputError(
            "Найдены строки импорта версии 0.1 без устойчивых ID. Создайте копию проекта и удалите старые импортированные участки перед повторной загрузкой, чтобы не удвоить длины."
        )
    existing = {b["id"]: b for b in target["branches"]}
    old_segments = {
        s["id"]: s for s in target["segments"] if s.get("_import", {}).get("batch") == batch
    }
    new_segments = []
    seen = {}
    counts = {}
    powers = {}
    explicit_ids = set()
    used_systems = set()
    incoming_rows = 0
    for ri, row in enumerate(rows[header_index + 1 :], header_index + 2):

        def get(k):
            ci = fields[k]
            v = row[ci] if ci is not None and ci < len(row) else None
            if isinstance(v, CellProblem):
                raise InputError(f"Строка {ri}: {v}")
            return v

        bid = text(get("branch"))
        if not bid or bid == "0" or "итого" in bid.lower():
            continue
        incoming_rows += 1
        sid = text(get("system"))
        cid = text(get("collector"))
        old = existing.get(bid)
        if not sid:
            sid = (
                old["system_id"]
                if old
                else (target["systems"][0]["id"] if len(target["systems"]) == 1 else "")
            )
            warnings.append(
                f'{bid}: номер системы {sid or "не определён"} взят из проекта; проверьте.'
            )
        if not sid:
            raise InputError(f"Строка {ri}: требуется явный номер системы.")
        if not cid:
            cid = old["collector_id"] if old else (bid.rsplit("-", 1)[0] if "-" in bid else "")
            warnings.append(
                f'{bid}: коллектор {cid or "не определён"} взят из проекта/номера ветки; проверьте.'
            )
        if not cid:
            raise InputError(f"{bid}: не задан номер коллектора.")
        if old and (old["system_id"] != sid or old["collector_id"] != cid):
            raise InputError(
                f"{bid}: конфликт системы/коллектора. ID ветки должен быть уникальным в проекте."
            )
        if bid in seen and seen[bid] != (sid, cid):
            raise InputError(f"{bid}: повтор ID в разных системах/коллекторах.")
        seen[bid] = (sid, cid)
        used_systems.add(sid)
        if not old:
            old = {
                "id": bid,
                "system_id": sid,
                "collector_id": cid,
                "name": text(get("name")) or bid,
                "heat_w": 0,
                "main_path": [],
                "path_complete": False,
            }
            target["branches"].append(old)
            existing[bid] = old
        old["path_complete"] = False
        hv = get("manual_heat")
        heat_field = "manual_heat"
        if hv in (None, ""):
            hv = get("heat")
            heat_field = "heat"
        if hv not in (None, ""):
            heat = number(hv, f"Строка {ri}: мощность", maximum=1e9)
            if fields[heat_field] is not None and (
                "квт" in header[fields[heat_field]] or header[fields[heat_field]] == "heatkw"
            ):
                heat *= 1000
            # The selected basis defines equipment power. Never add pipe-row duplicates.
            raw_equipment = fields["quantity"] is not None and fields["unit"] is not None
            unit = norm(get("unit"))
            if raw_equipment and heat:
                if unit not in ("шт", "штука", "штук", "pcs", ""):
                    raise InputError(
                        f'Строка {ri}: мощность в строке с единицей «{get("unit")}». Уточните отдельную ведомость приборов.'
                    )
                qty = number(
                    get("quantity") if get("quantity") not in (None, "") else 1,
                    f"Строка {ri}: число приборов",
                    positive=True,
                    maximum=100000,
                )
                if not qty.is_integer():
                    raise InputError(f"Строка {ri}: число приборов должно быть целым.")
                if heat_basis == "per_item":
                    heat *= qty
                elif qty > 1:
                    warnings.append(
                        f"{bid}: мощность строки принята суммарной для {qty:g} приборов. Проверьте режим мощности при импорте."
                    )
                powers.setdefault(bid, []).append(heat)
            elif not raw_equipment:
                values = powers.setdefault(bid, [])
                if values and not math_close(values[0], heat):
                    raise InputError(
                        f"{bid}: разные мощности одной ветки. В сводном шаблоне укажите одинаковую общую нагрузку."
                    )
                powers[bid] = [heat]
        length = get("length")
        unit = norm(get("unit"))
        if length in (None, "") and unit in ("м", "m", "мм", "mm"):
            length = get("quantity")
            length_factor = 0.001 if unit in ("мм", "mm") else 1
        else:
            length_factor = (
                0.001
                if fields["length"] is not None
                and header[fields["length"]] in ("lengthmm", "длинамм", "длинатрубмм")
                else 1
            )
        resistance = any(get(k) not in (None, "") for k in ("zeta", "kv", "extra"))
        if length in (None, "") and not resistance:
            continue
        # Kv is for one physical device; an aggregate row cannot become one valve.
        if (
            resistance
            and get("kv") not in (None, "")
            and fields["quantity"] is not None
            and unit in ("шт", "pcs")
        ):
            if number(get("quantity"), f"Строка {ri}: количество") != 1:
                raise InputError(
                    f"Строка {ri}: Kv относится к одному изделию. Разделите несколько изделий на отдельные строки с ID."
                )
        values = {
            "length_m": number(length if length not in (None, "") else 0, f"Строка {ri}: длина")
            * length_factor
        }
        for field, key in [
            ("inner", "inner_mm"),
            ("roughness", "roughness_mm"),
            ("zeta", "zeta"),
            ("kv", "kv_m3h"),
            ("extra", "extra_dp_pa"),
        ]:
            v = get(field)
            if v not in (None, ""):
                values[key] = number(v, f"Строка {ri}: {field}", positive=field == "kv")
                if field == "inner" and header[fields[field]] in ("innerm", "внутреннийдиаметрм"):
                    values[key] *= 1000
                if field == "extra" and "кпа" in header[fields[field]]:
                    values[key] *= 1000
        if get("extra_model") not in (None, ""):
            values["extra_model"] = text(get("extra_model"))
        rowid = text(get("row_id"))
        if rowid:
            if rowid in explicit_ids:
                raise InputError(f"Повтор ID участка {rowid}; используйте уникальные ID.")
            explicit_ids.add(rowid)
            token = "id:" + rowid
        else:
            signature = json.dumps(
                [bid, text(get("name")), text(get("nominal")), values],
                ensure_ascii=False,
                sort_keys=True,
            )
            token = "row:" + hashlib.sha256(signature.encode()).hexdigest()[:20]
            counts[token] = counts.get(token, 0) + 1
            token += f":{counts[token]}"
        segid = "X-" + batch + "-" + hashlib.sha256(token.encode()).hexdigest()[:20]
        previous_seg = old_segments.get(segid)
        seg = (
            copy.deepcopy(previous_seg)
            if previous_seg
            else {
                "id": segid,
                "branch_id": bid,
                "length_m": 0,
                "inner_mm": 0,
                "roughness_mm": 0.007,
                "zeta": 0,
                "kv_m3h": None,
                "extra_dp_pa": 0,
                "extra_model": "design",
            }
        )
        if previous_seg and previous_seg["branch_id"] != bid:
            raise InputError(
                f"Строка {ri}: участок {rowid} перенесён в другую ветку; проверьте и удалите прежний участок явно."
            )
        prior_values = previous_seg.get("_import", {}).get("values", {}) if previous_seg else {}
        for key, value in values.items():
            if (
                previous_seg
                and key in prior_values
                and seg.get(key) != prior_values[key]
                and value != prior_values[key]
                and seg.get(key) != value
            ):
                raise InputError(
                    f"{bid}, строка {ri}: конфликт ручного и внешнего изменения поля {key}. Согласуйте значения до импорта."
                )
            if (
                previous_seg
                and key in prior_values
                and seg.get(key) != prior_values[key]
                and value == prior_values[key]
            ):
                warnings.append(f"{bid}/{segid}: сохранена ручная правка {key}.")
            else:
                seg[key] = value
        seg["source"] = {
            "file": Path(path).name,
            "sheet": sheet,
            "row": ri,
            "nominal_diameter": text(get("nominal")),
            "external_id": rowid,
        }
        # Track defaults too: a newly supplied Excel column must not silently
        # overwrite a manual value entered while that column was absent.
        baseline = {
            "inner_mm": 0,
            "roughness_mm": 0.007,
            "zeta": 0,
            "kv_m3h": None,
            "extra_dp_pa": 0,
            "extra_model": "design",
        }
        seg["_import"] = {
            "batch": batch,
            "identity": token,
            "values": {**baseline, **prior_values, **values},
        }
        new_segments.append(seg)
        if get("roughness") in (None, "") and not previous_seg:
            warnings.append(
                f"{bid}: принята шероховатость 0,007 мм; проверьте материал и состояние трубы."
            )
        if not seg["inner_mm"]:
            warnings.append(
                f"{bid}: заполните внутренний диаметр; номинальный диаметр не подставляется автоматически."
            )
        if not any(seg.get(k) for k in ("zeta", "kv_m3h", "extra_dp_pa")):
            warnings.append(
                f"{bid}: импортированы трубы без сопротивлений; проверьте арматуру и прибор."
            )
    if not incoming_rows:
        raise InputError("Нет заполненных веток; пустой лист не используется для удаления данных.")
    other_bids = {s["branch_id"] for s in target["segments"] if s["id"] not in old_segments}
    for bid in {s["branch_id"] for s in new_segments} & other_bids:
        warnings.append(
            f"{bid}: уже есть участки вне обновляемого источника. Новые строки добавятся к ним; проверьте отсутствие двойного учёта труб."
        )
    new_ids = {s["id"] for s in new_segments}
    removed = [s for k, s in old_segments.items() if k not in new_ids]
    if removed:
        warnings.append(
            f"Снимок источника заменён: удалено прежних участков {len(removed)}. Проверьте длины и ручные данные удалённых строк; действие можно отменить."
        )
    for seg in removed:
        if seg["branch_id"] in existing:
            existing[seg["branch_id"]]["path_complete"] = False
    target["segments"] = [
        s for s in target["segments"] if s["id"] not in old_segments
    ] + new_segments
    old_power = previous.get("powers", {}) if previous else {}
    incoming_power = {bid: sum(values) for bid, values in powers.items()}
    for bid in set(old_power) | set(incoming_power):
        b = existing.get(bid)
        if b is None:
            continue
        new_value = incoming_power.get(bid, 0)
        if bid in old_power and number(b.get("heat_w", 0), bid) != old_power[bid]:
            if new_value != old_power[bid] and new_value != number(b["heat_w"], bid):
                raise InputError(
                    f"{bid}: конфликт ручной и импортированной мощности. Согласуйте значение."
                )
            warnings.append(f"{bid}: сохранена вручную изменённая мощность.")
        else:
            # Prevent independent heat sources silently overwriting each other.
            others = [s for s in sources if s.get("id") != batch and bid in s.get("powers", {})]
            if others and any(s["powers"][bid] != new_value for s in others):
                raise InputError(
                    f"{bid}: конфликт мощностей разных источников; обновите прежний источник."
                )
            b["heat_w"] = new_value
        b["path_complete"] = False
    for bid in seen:
        if not existing[bid].get("heat_w"):
            warnings.append(f"{bid}: задайте расчётную мощность.")
    known = {s["id"] for s in target["systems"]}
    for sid in sorted(used_systems - known):
        target["systems"].append(default_system(sid))
        warnings.append(f"{sid}: начальный режим вода 80/60 °C; проверьте.")
    warnings.append(
        "Мощности из колонок Q приняты согласно ведомости; соответствие расчётному температурному режиму проверяется пользователем."
    )
    if not explicit_ids:
        warnings.append(
            "В источнике нет ID участков. Перестановка одинаковых строк поддержана; изменённая строка создаётся заново без переноса ручных свойств. Для устойчивого обновления используйте ID участка / UniqueId."
        )
    source = {
        "id": batch,
        "path": filepath,
        "file": Path(path).name,
        "sheet": sheet,
        "sha256": digest,
        "heat_basis": heat_basis,
        "powers": incoming_power,
        "row_count": incoming_rows,
        "segment_count": len(new_segments),
        "removed_segments": len(removed),
        "warnings": list(dict.fromkeys(warnings)),
    }
    target["imports"] = [s for s in sources if s.get("id") != batch] + [source]
    validate_project(target)
    return target, source["warnings"]


def math_close(a, b):
    return abs(a - b) <= max(1e-8, abs(a) * 1e-10)


def style_book(w):
    from openpyxl.styles import Font, PatternFill, Alignment

    for s in w:
        s.freeze_panes = "A2"
        s.auto_filter.ref = s.dimensions
        for c in s[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="254E70")
            c.alignment = Alignment(wrap_text=True, vertical="center")
        s.row_dimensions[1].height = 44
        for col in s.columns:
            s.column_dimensions[col[0].column_letter].width = 26
        for row in s.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    c.data_type = "s"  # Never export user text as a formula.
                elif isinstance(c.value, float):
                    c.number_format = "0.000"
    return w


def save_workbook(w, path):
    buf = io.BytesIO()
    try:
        w.save(buf)
        try:
            atomic_bytes(path, buf.getvalue())
        except PermissionError as error:
            raise InputError(
                "Не удалось сохранить Excel. Закройте этот файл в Excel и повторите экспорт "
                "или выберите другое имя и папку с правом записи. "
                f"Файл: {path}"
            ) from error
        except OSError as error:
            raise InputError(
                f"Не удалось сохранить Excel: {error}. Проверьте папку, свободное место "
                "и попробуйте сохранить под другим именем."
            ) from error
    finally:
        w.close()


def excel_value(value):
    """Keep exported text literal and XML-safe; full data remain in the JSON sheet."""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if isinstance(value, str):
        # Control characters can occur in imported names even in a valid JSON project.
        value = re.sub(
            r"[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]",
            lambda match: "\\u%04x" % ord(match.group()),
            value,
        )
        if len(value) > 32767:
            suffix = " … [полное значение: лист «Исходные данные JSON»]"
            value = value[: 32767 - len(suffix)] + suffix
    return value


def append_row(sheet, values):
    sheet.append([excel_value(value) for value in values])
    # Set immediately, including values beginning '=' or Excel error tokens.
    for cell in sheet[sheet.max_row]:
        if isinstance(cell.value, str):
            cell.data_type = "s"


def append_inputs_json(w, project):
    sheet = w.create_sheet("Исходные данные JSON")
    append_row(sheet, ["Часть", "JSON: соединить части без разделителя"])
    # ASCII escaping keeps arbitrary Unicode and XML control characters reversible.
    raw = json.dumps(project, ensure_ascii=True, indent=2, allow_nan=False)
    for index in range(0, len(raw), 30000):
        append_row(sheet, [index // 30000 + 1, raw[index : index + 30000]])


def write_table(w, name, rows, labels):
    sheet = w.create_sheet(name)
    keys = list(dict.fromkeys(key for row in rows for key in row))
    append_row(sheet, [labels.get(key, key) for key in keys] or ["Нет данных"])
    for row in rows:
        append_row(sheet, [row.get(key) for key in keys])
    return sheet


def create_template(path):
    import openpyxl

    w = openpyxl.Workbook()
    s = w.active
    s.title = "Ввод веток"
    s.append(
        [
            "Номер системы",
            "Номер коллектора",
            "Номер ветки",
            "Наименование",
            "Мощность, Вт",
            "Длина, м",
            "Внутренний диаметр, мм",
            "Шероховатость, мм",
            "КМС",
            "Kv",
            "Доп. потери, Па",
            "ID участка",
            "Закон доп. потерь",
        ]
    )
    s.append(
        [
            "1.1",
            "101",
            "101-1",
            "Радиатор 1",
            1000,
            20,
            11.6,
            0.007,
            8,
            None,
            0,
            "101-1-подводка",
            "design",
        ]
    )
    s.append(
        [
            "1.1",
            "101",
            "101-2",
            "Радиатор 2",
            1500,
            35,
            11.6,
            0.007,
            8,
            None,
            0,
            "101-2-подводка",
            "design",
        ]
    )
    s = w.create_sheet("Как заполнять")
    for row in [
        ["Поле", "Правило"],
        ["ID участка", "Устойчивый уникальный ID. Не меняйте при корректировке длины."],
        [
            "Мощность",
            "Общая расчётная нагрузка ветки. При нескольких её строках повторите одну мощность.",
        ],
        ["Длина", "Фактическая сумма подачи и обратки. Повторно на два не умножать."],
        ["Внутренний диаметр", "Из сортамента трубы, мм. Не подменять DN."],
        ["Разные диаметры", "Отдельные строки участков одной ветки."],
        [
            "Сопротивления",
            "Каждый Kv — одно изделие; для нескольких изделий отдельные строки с длиной 0. КМС и доп. потери — сумма строки.",
        ],
        [
            "Закон доп. потерь",
            "design: известны только при проектном расходе. quadratic: пользователь подтверждает пропорциональность квадрату расхода.",
        ],
        ["Магистрали", "Вводятся отдельно в приложении."],
        [
            "Импорт",
            "Повторная загрузка заменяет снимок выбранного источника, в том числе удалённые участки.",
        ],
        [
            "Формулы",
            "Перед импортом пересчитайте и сохраните XLSX в Excel. Приложение формулы не исполняет.",
        ],
    ]:
        s.append(row)
    style_book(w)
    w["Как заполнять"].column_dimensions["B"].width = 100
    save_workbook(w, path)


def export_project(project, path):
    """Export a saveable draft, including missing data, without claiming a calculation."""
    import openpyxl

    validate_project(project)
    w = openpyxl.Workbook()
    sheet = w.active
    sheet.title = "Исходные данные"
    append_row(sheet, ["Показатель", "Значение"])
    append_row(sheet, ["Проект", project["name"]])
    append_row(sheet, ["Статус", "Выгрузка исходных данных. Расчёт в этой книге не выполнен."])
    append_row(sheet, ["Число систем", len(project["systems"])])
    append_row(sheet, ["Число веток", len(project["branches"])])
    append_row(sheet, ["Число участков веток", len(project["segments"])])
    append_row(sheet, ["Число участков магистралей", len(project["mains"])])
    append_row(
        sheet,
        [
            "Как продолжить",
            "Заполните недостающие данные из листа «Готовность» и выполните расчёт в приложении.",
        ],
    )
    append_row(
        sheet,
        [
            "Повторный импорт",
            "«Ввод участков» можно импортировать как ведомость веток. Настройки систем, маршруты и магистрали задаются отдельно в приложении.",
        ],
    )
    common_labels = {
        "id": "ID",
        "name": "Название",
        "system_id": "Номер системы",
        "collector_id": "Номер коллектора",
        "heat_w": "Мощность, Вт",
        "main_path": "Магистрали пути",
        "path_complete": "Полнота кольца подтверждена",
        "supply_c": "Подача, °C",
        "return_c": "Обратка, °C",
        "coolant": "Теплоноситель",
        "properties_mode": "Режим свойств жидкости",
        "rho": "Плотность, кг/м³",
        "cp": "Теплоёмкость, Дж/(кг·К)",
        "nu_mm2_s": "Вязкость, мм²/с",
        "flow_margin_percent": "Запас расхода, %",
        "head_margin_percent": "Запас напора, %",
        "velocity_limit_ms": "Контроль скорости, м/с",
        "length_m": "Длина, м",
        "main_length_m": "Длина магистралей пути, м",
        "loop_length_m": "Длина труб полного пути, м",
        "inner_mm": "Внутренний диаметр, мм",
        "roughness_mm": "Шероховатость, мм",
        "zeta": "КМС",
        "kv_m3h": "Kv",
        "extra_dp_pa": "Доп. потери, Па",
        "extra_model": "Закон доп. потерь",
    }
    for name, key in [
        ("Ввод систем", "systems"),
        ("Ввод веток", "branches"),
        ("Ввод магистралей", "mains"),
    ]:
        write_table(w, name, project[key], common_labels)
    sheet = w.create_sheet("Ввод участков")
    append_row(
        sheet,
        [
            "ID участка",
            "Номер системы",
            "Номер коллектора",
            "Номер ветки",
            "Наименование",
            "Мощность, Вт",
            "Длина, м",
            "Внутренний диаметр, мм",
            "Шероховатость, мм",
            "КМС",
            "Kv",
            "Доп. потери, Па",
            "Закон доп. потерь",
        ],
    )
    branches = {branch["id"]: branch for branch in project["branches"]}
    for segment in project["segments"]:
        branch = branches[segment["branch_id"]]
        append_row(
            sheet,
            [
                segment["id"],
                branch["system_id"],
                branch["collector_id"],
                branch["id"],
                branch.get("name", ""),
                branch.get("heat_w", 0),
                segment["length_m"],
                segment["inner_mm"],
                segment.get("roughness_mm", 0.007),
                segment.get("zeta", 0),
                segment.get("kv_m3h"),
                segment.get("extra_dp_pa", 0),
                segment.get("extra_model", "design"),
            ],
        )
    sheet = w.create_sheet("Готовность")
    append_row(sheet, ["Уровень", "Элемент", "Что проверить или заполнить"])
    issues = readiness(project)
    for issue in issues:
        append_row(
            sheet,
            [
                "Ошибка" if issue["severity"] == "error" else "Проверить",
                issue["id"],
                issue["message"],
            ],
        )
    if not issues:
        append_row(
            sheet, ["Готово", "Проект", "Исходные данные заполнены; выполните расчёт в приложении."]
        )
    append_inputs_json(w, project)
    style_book(w)
    w["Исходные данные"].column_dimensions["B"].width = 105
    w["Готовность"].column_dimensions["C"].width = 100
    save_workbook(w, path)


def export_results(result, path):
    import openpyxl

    w = openpyxl.Workbook()
    w.remove(w.active)
    labels = {
        "id": "ID",
        "name": "Название",
        "system_id": "Система",
        "collector_id": "Коллектор",
        "branch_id": "Ветка",
        "heat_w": "Мощность, Вт",
        "mass_kgh": "Массовый расход, кг/ч",
        "flow_m3h": "Расход, м³/ч",
        "length_m": "Длина, м",
        "main_length_m": "Длина магистралей пути, м",
        "loop_length_m": "Длина труб полного пути, м",
        "inner_mm": "dвнутр, мм",
        "max_velocity_ms": "Макс. скорость, м/с",
        "branch_dp_pa": "Подводка, Па",
        "main_dp_pa": "Магистраль, Па",
        "loop_dp_pa": "Учтённые потери кольца, Па",
        "balance_dp_pa": "Добавить балансировкой, Па",
        "path_complete": "Полнота подтверждена",
        "velocity_ms": "Скорость, м/с",
        "dp_pa": "Потери, Па",
        "head_m": "Напор, м жидкости",
        "complete": "Полнота подтверждена",
        "critical_loop_id": "Диктующее кольцо",
        "critical_loop_ids": "Все диктующие кольца",
        "candidate_loop_id": "Максимум учтённых путей",
        "head_with_margin_m": "Напор с запасами, м",
        "flow_with_margin_m3h": "Расход с запасом, м³/ч",
        "dp_at_increased_flow_pa": "Потери при увеличенном расходе, Па",
        "margin_critical_loop_ids": "Диктующие при увеличенном расходе",
        "r_pa_m": "R, Па/м",
        "regime": "Режим",
        "dp_linear_pa": "Трение, Па",
        "dp_local_pa": "Местные, Па",
        "dp_kv_pa": "Kv, Па",
        "dp_extra_pa": "Дополнительные, Па",
        "source": "Источник",
        "rho": "Плотность, кг/м³",
        "cp": "Теплоёмкость, Дж/(кг·К)",
        "nu_mm2_s": "Вязкость, мм²/с",
        "properties_mode": "Режим свойств жидкости",
        "margin_status": "Статус расчёта с запасом",
        "branch_ids": "Ветки-потребители",
        "main_path": "Магистрали пути",
        "max_calculated_dp_pa": "Максимум учтённых потерь, Па",
        "most_loaded_branch_id": "Самая мощная ветка",
        "most_loaded_branch_ids": "Все самые мощные ветки",
        "most_loaded_branch_heat_w": "Макс. мощность ветки, Вт",
        "highest_flow_branch_ids": "Ветки с максимальным расходом",
        "highest_branch_flow_m3h": "Макс. расход ветки, м³/ч",
        "max_branch_id": "Макс. потери подводки",
        "max_branch_ids": "Ветки с макс. потерями подводки",
        "candidate_loop_ids": "Все максимумы учтённых путей",
        "margin_candidate_loop_ids": "Максимумы при увеличенном расходе",
        "is_most_loaded": "Максимум тепловой нагрузки",
        "is_highest_flow": "Максимум расхода ветки",
        "is_max_branch_loss": "Максимум потерь подводки",
        "is_candidate_loop": "Максимум учтённых потерь кольца",
        "is_critical_loop": "Диктующее кольцо подтверждено",
        "supply_c": "Подача, °C",
        "return_c": "Обратка, °C",
        "branch_count": "Число веток",
        "max_branch_dp_pa": "Макс. подводка, Па",
        "re": "Число Рейнольдса Re",
        "lambda": "Коэффициент трения λ",
    }
    sheet = w.create_sheet("Сводка")
    append_row(sheet, ["Система", "Показатель", "Значение", "Единица / пояснение"])
    append_row(sheet, ["Проект", "Название", result.get("inputs", {}).get("name", ""), ""])
    for system in result.get("systems", []):
        sid = system["id"]
        branches = [branch for branch in result.get("branches", []) if branch["system_id"] == sid]
        by_id = {branch["id"]: branch for branch in branches}
        heat_max = max((branch["heat_w"] for branch in branches), default=0)
        loaded_ids = system.get("most_loaded_branch_ids") or [
            branch["id"]
            for branch in branches
            if math.isclose(branch["heat_w"], heat_max, rel_tol=1e-9, abs_tol=1e-6)
        ]
        candidate_ids = system.get("candidate_loop_ids") or [system.get("candidate_loop_id")]
        candidate_ids = [identifier for identifier in candidate_ids if identifier in by_id]
        complete = system.get("complete", False)
        for title, value, note in [
            ("Статус расчёта", "Полнота подтверждена" if complete else "Неполная схема", ""),
            (
                "Самая мощная ветка",
                ", ".join(loaded_ids),
                "По тепловой нагрузке; все равные максимумы",
            ),
            ("Макс. мощность ветки", heat_max, "Вт"),
            (
                "Диктующее кольцо",
                ", ".join(system.get("critical_loop_ids", [])) if complete else "Не определено",
                "По сумме потерь ветки и её магистралей; для полного кольца",
            ),
            (
                "Кандидаты по учтённым потерям",
                ", ".join(candidate_ids),
                "При неполной схеме максимум предварительный",
            ),
            ("Мощность системы", system.get("heat_w"), "Вт"),
            ("Расход системы", system.get("flow_m3h"), "м³/ч; сумма расходов её веток"),
            (
                "Максимум учтённых потерь кольца",
                system.get("max_calculated_dp_pa"),
                "Па; ветка + магистрали её маршрута",
            ),
            ("Расчётный напор", system.get("head_m"), "м жидкости; доступен для полной схемы"),
            ("Расход с запасом", system.get("flow_with_margin_m3h"), "м³/ч"),
            (
                "Напор с запасами",
                system.get("head_with_margin_m"),
                "м жидкости; потери пересчитаны при увеличенном расходе",
            ),
            ("Статус расчёта с запасом", system.get("margin_status"), ""),
        ]:
            append_row(sheet, [sid, title, value, note])
        for candidate_id in candidate_ids:
            branch = by_id[candidate_id]
            append_row(
                sheet,
                [
                    sid,
                    f"{candidate_id}: потери ветки",
                    branch["branch_dp_pa"],
                    "Па; все её участки подачи и обратки",
                ],
            )
            append_row(
                sheet,
                [
                    sid,
                    f"{candidate_id}: потери магистралей",
                    branch["main_dp_pa"],
                    "Па; все магистрали маршрута подачи и обратки",
                ],
            )
            append_row(
                sheet,
                [
                    sid,
                    f"{candidate_id}: сумма потерь кольца",
                    branch["loop_dp_pa"],
                    "Па; потери ветки + потери магистралей",
                ],
            )
    systems = result.get("systems", [])
    append_row(
        sheet,
        [
            "Все системы",
            "Суммарная тепловая нагрузка",
            math.fsum(system.get("heat_w", 0) for system in systems),
            "Вт",
        ],
    )
    append_row(
        sheet,
        [
            "Все системы",
            "Сумма расчётных расходов систем",
            math.fsum(system.get("flow_m3h", 0) for system in systems),
            "м³/ч; справочно, не означает один насос здания",
        ],
    )
    append_row(
        sheet,
        [
            "Пояснение",
            "Напор по зданию",
            "Не суммируется",
            "Насос выбирают для конкретного циркуляционного контура; независимые системы рассчитывают отдельно.",
        ],
    )
    append_row(
        sheet,
        [
            "Пояснение",
            "Цвета на листе «Ветки»",
            "Оранжевый — диктующее кольцо; зелёный — максимум тепловой нагрузки",
            "Если обе роли совпадают, строка оранжевая; отдельные столбцы показывают каждую роль.",
        ],
    )
    append_row(
        sheet,
        [
            "Пояснение",
            "Общая магистраль",
            "Расход всех обслуживаемых веток",
            "Её потери включаются один раз в каждое соответствующее кольцо; потери параллельных веток не складывают.",
        ],
    )
    for name, key in [
        ("Системы", "systems"),
        ("Коллекторы", "collectors"),
        ("Ветки", "branches"),
        ("Участки", "segments"),
        ("Магистрали", "mains"),
    ]:
        rows = result.get(key, [])
        write_table(w, name, rows, labels)
    s = w.create_sheet("Замечания")
    append_row(s, ["Замечание"])
    for item in result.get("warnings", []):
        append_row(s, [item])
    append_row(
        s,
        [
            "Это расчёт проектных расходов. Фактическая балансировка и характеристика конкретного насоса не моделируются."
        ],
    )
    s = w.create_sheet("Паспорт расчёта")
    append_row(s, ["Поле", "Значение"])
    for k, v in result.get("metadata", {}).items():
        append_row(s, [k, v])
    append_inputs_json(w, result.get("inputs", {}))
    style_book(w)
    w["Сводка"].column_dimensions["A"].width = 20
    w["Сводка"].column_dimensions["B"].width = 43
    w["Сводка"].column_dimensions["C"].width = 42
    w["Сводка"].column_dimensions["D"].width = 100
    from openpyxl.styles import Alignment, PatternFill

    for row in w["Сводка"].iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        if isinstance(row[2].value, (float, int)) and "м³/ч" in str(row[3].value):
            row[2].number_format = "0.000000"

    for row, data in zip(w["Ветки"].iter_rows(min_row=2), result.get("branches", [])):
        system = next((item for item in systems if item["id"] == data["system_id"]), {})
        if data["id"] in system.get("critical_loop_ids", []):
            color = "FFE1C2"
        elif data["id"] in system.get(
            "most_loaded_branch_ids", [system.get("most_loaded_branch_id")]
        ):
            color = "DCF2E1"
        else:
            continue
        for cell in row:
            cell.fill = PatternFill("solid", fgColor=color)
    w["Замечания"].column_dimensions["A"].width = 110
    save_workbook(w, path)
