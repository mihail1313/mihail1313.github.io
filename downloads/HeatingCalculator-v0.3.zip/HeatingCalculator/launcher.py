"""GUI entry point with startup diagnostics (also works with pythonw/PyInstaller)."""

from pathlib import Path
from datetime import datetime
import os, sys, traceback


def main():
    from app import App
    from hydraulics import load_project, file_digest
    from tkinter import messagebox

    app = App()
    if len(sys.argv) > 1:
        try:
            app.project = load_project(sys.argv[1])
            app.path = sys.argv[1]
            app.disk_digest = file_digest(app.path)
            app.refresh()
        except (OSError, ValueError) as error:
            messagebox.showerror("Открытие проекта", str(error), parent=app)
    app.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        detail = traceback.format_exc()
        message = "The application could not start. Run Install.cmd again.\n"
        try:
            folder = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "HeatingCalculator"
            folder.mkdir(parents=True, exist_ok=True)
            log = folder / "startup.log"
            with log.open("a", encoding="utf-8") as stream:
                stream.write(datetime.now().isoformat() + "\n" + detail + "\n")
            message += "Log: " + str(log)
        except OSError:
            message += detail
        if sys.platform == "win32":
            import ctypes

            ctypes.windll.user32.MessageBoxW(None, message, "Heating Calculator", 0x10)
        elif sys.stderr:
            sys.stderr.write(message + "\n" + detail)
        sys.exit(1)
