"""Validated project edits, detached from widgets. Failed edits never mutate the input."""

import copy
from hydraulics import InputError, validate_project


def edit_row(project, key, index, updated):
    p = copy.deepcopy(project)
    row = copy.deepcopy(updated)
    if index is None:
        p[key].append(row)
    else:
        original = p[key][index]
        old = original["id"]
        new = row["id"]
        p[key][index] = row
        if key == "branches":
            if original.get("main_path", []) != row.get("main_path", []) or original.get(
                "system_id"
            ) != row.get("system_id"):
                row["path_complete"] = False
            for s in p["segments"]:
                if s["branch_id"] == old:
                    s["branch_id"] = new
        if key == "systems":
            for r in p["branches"] + p["mains"]:
                if r["system_id"] == old:
                    r["system_id"] = new
        if key == "mains":
            for b in p["branches"]:
                b["main_path"] = [new if m == old else m for m in b.get("main_path", [])]
    if key in ("segments", "mains"):
        for b in p["branches"]:
            if (key == "segments" and b["id"] == row["branch_id"]) or (
                key == "mains" and row["id"] in b.get("main_path", [])
            ):
                b["path_complete"] = False
        if index is not None and key == "segments":
            for b in p["branches"]:
                if b["id"] == original["branch_id"]:
                    b["path_complete"] = False
    validate_project(p)
    return p


def delete_rows(project, key, indices):
    p = copy.deepcopy(project)
    ids = {p[key][i]["id"] for i in indices}
    if key == "systems" and any(r["system_id"] in ids for r in p["branches"] + p["mains"]):
        raise InputError("Система используется: сначала удалите её ветки и магистрали.")
    p[key] = [r for r in p[key] if r["id"] not in ids]
    if key == "branches":
        sids = {b["system_id"] for b in project["branches"] if b["id"] in ids}
        p["segments"] = [r for r in p["segments"] if r["branch_id"] not in ids]
        for b in p["branches"]:
            if b["system_id"] in sids:
                b["path_complete"] = False
    if key == "segments":
        bids = {r["branch_id"] for r in project["segments"] if r["id"] in ids}
        for b in p["branches"]:
            if b["id"] in bids:
                b["path_complete"] = False
    if key == "mains":
        for b in p["branches"]:
            if ids.intersection(b.get("main_path", [])):
                b["main_path"] = [m for m in b["main_path"] if m not in ids]
                b["path_complete"] = False
    validate_project(p)
    return p


def bulk_update(project, key, indices, field, value):
    allowed = {
        "segments": {"inner_mm", "roughness_mm", "zeta", "extra_model"},
        "mains": {"inner_mm", "roughness_mm", "zeta", "extra_model"},
        "branches": {"path_complete", "main_path", "collector_id"},
    }
    if field not in allowed.get(key, set()):
        raise InputError("Это поле недоступно для массового изменения.")
    p = copy.deepcopy(project)
    affected = set()
    for i in indices:
        row = p[key][i]
        row[field] = copy.deepcopy(value)
        if key == "branches" and field == "main_path":
            row["path_complete"] = False
        if key == "segments":
            affected.add(row["branch_id"])
        elif key == "mains":
            affected.update(b["id"] for b in p["branches"] if row["id"] in b.get("main_path", []))
    for b in p["branches"]:
        if b["id"] in affected:
            b["path_complete"] = False
    validate_project(p)
    return p


class History:
    def __init__(self, limit=40):
        self.undo_stack = []
        self.redo_stack = []
        self.limit = limit

    def push(self, current):
        self.undo_stack.append(copy.deepcopy(current))
        self.undo_stack = self.undo_stack[-self.limit :]
        self.redo_stack.clear()

    def undo(self, current):
        if not self.undo_stack:
            return None
        self.redo_stack.append(copy.deepcopy(current))
        return self.undo_stack.pop()

    def redo(self, current):
        if not self.redo_stack:
            return None
        self.undo_stack.append(copy.deepcopy(current))
        return self.redo_stack.pop()
