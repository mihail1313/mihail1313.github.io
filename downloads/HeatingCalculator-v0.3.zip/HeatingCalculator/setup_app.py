"""Windows installer: app-local environment, log, desktop shortcut. No Revit changes."""

from pathlib import Path
import os, subprocess, sys, venv, traceback


def main():
    if sys.platform != "win32":
        raise RuntimeError(
            "Windows installer. Linux: pip install -r requirements.txt; python launcher.py"
        )
    if not (3, 11) <= sys.version_info[:2] <= (3, 14):
        raise RuntimeError("Use Python 3.11 through 3.14 with Tcl/Tk and pip.")
    import tkinter

    base = Path(__file__).resolve().parent
    env = base / ".venv"
    logpath = base / "install.log"
    print("Installation folder:", base, flush=True)
    print("Log:", logpath, flush=True)
    with logpath.open("w", encoding="utf-8") as log:
        log.write("Base Python: " + sys.executable + "\n" + sys.version + "\n")
        log.flush()

        def status(message):
            print(message, flush=True)
            log.write(message + "\n")
            log.flush()

        def run(args):
            process = subprocess.Popen(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env={**os.environ, "PYTHONIOENCODING": "utf-8"},
            )
            for line in process.stdout:
                print(line, end="", flush=True)
                log.write(line)
                log.flush()
            if process.wait():
                raise RuntimeError(f"Command failed (exit {process.returncode}). See {logpath}")

        python = env / "Scripts/python.exe"
        if not python.exists():
            status("[1/4] Creating the Python environment. This can take a few minutes...")
            venv.EnvBuilder(with_pip=True).create(env)
        else:
            status("[1/4] Checking the existing Python environment...")
        run(
            [
                str(python),
                "-c",
                'import sys,tkinter; assert (3,11)<=sys.version_info[:2]<=(3,14), "Unsupported Python"; print(sys.executable)',
            ]
        )
        status("[2/4] Installing Excel support. Internet access is required...")
        run(
            [
                str(python),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "-r",
                str(base / "requirements.txt"),
            ]
        )
        status("[3/4] Checking the interface and calculation...")
        run(
            [
                str(python),
                "-c",
                'import tkinter,openpyxl; from hydraulics import calculate,demo_project; root=tkinter.Tk(); root.withdraw(); root.update_idletasks(); root.destroy(); assert calculate(demo_project())["systems"][0]["head_m"]>0; print("Dependencies, Tk interface and calculation OK")',
            ]
        )

        def quote(s):
            return "'" + str(s).replace("'", "''") + "'"

        command = (
            "$ErrorActionPreference='Stop';$shell=New-Object -ComObject WScript.Shell;"
            "$desktop=[Environment]::GetFolderPath('Desktop');"
            "$shortcut=$shell.CreateShortcut((Join-Path $desktop 'Heating Calculator.lnk'));"
            "$shortcut.TargetPath=" + quote(env / "Scripts/pythonw.exe") + ";"
            "$shortcut.Arguments=" + quote('"' + str(base / "launcher.py") + '"') + ";"
            "$shortcut.WorkingDirectory=" + quote(base) + ";"
            "$shortcut.Description='Heating hydraulic calculator';$shortcut.Save()"
        )
        status("[4/4] Creating the desktop shortcut...")
        try:
            run(["powershell.exe", "-NoProfile", "-Command", command])
        except RuntimeError:
            print("Shortcut could not be created. Launch.cmd is available. Details in install.log.")
    print(
        "\nInstalled. Use Heating Calculator on your desktop or Launch.cmd.\nKeep the application folder in this location."
    )


if __name__ == "__main__":
    os.chdir(Path(__file__).resolve().parent)
    try:
        main()
    except Exception as exc:
        print("\nSETUP FAILED:", exc)
        try:
            with Path("install.log").open("a", encoding="utf-8") as log:
                log.write(traceback.format_exc())
        except OSError:
            pass
        sys.exit(1)
