import copy, math, tempfile, unittest
from pathlib import Path
from hydraulics import *
from excel_io import import_table, create_template, export_results


class HydraulicsTests(unittest.TestCase):
    def setUp(self):
        self.s = default_system()
        self.s.update(rho=1000, nu_mm2_s=1, cp=4200)
        self.seg = {
            "id": "S",
            "length_m": 10,
            "inner_mm": 10,
            "roughness_mm": 0,
            "zeta": 0,
            "extra_dp_pa": 0,
        }

    def test_heat_balance(self):
        p = demo_project()
        r = calculate(p)
        for b in r["branches"]:
            self.assertAlmostEqual(b["mass_kgh"], b["heat_w"] / 4190 / 20 * 3600)

    def test_laminar_poiseuille(self):
        # v=.1 m/s; Re=1000. Hagen-Poiseuille gives dp=32 mu v L / D² = 320 Pa.
        mass = 1000 * 0.1 * math.pi * 0.01**2 / 4
        r = segment_loss(self.seg, mass, self.s)
        self.assertAlmostEqual(r["re"], 1000)
        self.assertAlmostEqual(r["lambda"], 0.064)
        self.assertAlmostEqual(r["dp_pa"], 320)

    def test_turbulent_reference(self):
        seg = dict(self.seg, inner_mm=100, roughness_mm=0)
        mass = 1000 * 1 * math.pi * 0.1**2 / 4
        r = segment_loss(seg, mass, self.s)
        self.assertAlmostEqual(r["re"], 100000)
        self.assertAlmostEqual(r["lambda"], 0.01799, delta=0.0003)

    def test_transition_marked(self):
        mass = 1000 * 0.3 * math.pi * 0.01**2 / 4
        self.assertEqual(segment_loss(self.seg, mass, self.s)["regime"], "Переходный")

    def test_kv_reference(self):
        seg = dict(self.seg, length_m=0, kv_m3h=1)
        self.assertAlmostEqual(segment_loss(seg, 1000 / 3600, self.s)["dp_pa"], 100000)

    def test_local_dynamic_pressure(self):
        seg = dict(self.seg, length_m=0, zeta=2)
        mass = 1000 * 0.1 * math.pi * 0.01**2 / 4
        self.assertAlmostEqual(segment_loss(seg, mass, self.s)["dp_pa"], 10)

    def test_zero_flow(self):
        r = segment_loss(dict(self.seg, zeta=10, kv_m3h=2, extra_dp_pa=3000), 0, self.s)
        self.assertEqual(r["dp_pa"], 0)

    def test_split_length(self):
        r = segment_loss(self.seg, 0.01, self.s)
        a = segment_loss(dict(self.seg, length_m=4), 0.01, self.s)
        b = segment_loss(dict(self.seg, length_m=6), 0.01, self.s)
        self.assertAlmostEqual(a["dp_pa"] + b["dp_pa"], r["dp_pa"])

    def test_shared_main_sums_flows_once(self):
        r = calculate(demo_project())
        total = sum(x["flow_m3h"] for x in r["branches"])
        for main in r["mains"]:
            self.assertAlmostEqual(main["flow_m3h"], total)
        self.assertAlmostEqual(r["systems"][0]["flow_m3h"], total)

    def test_critical_max_not_sum(self):
        r = calculate(demo_project())
        s = r["systems"][0]
        expected = max(x["loop_dp_pa"] for x in r["branches"])
        self.assertAlmostEqual(s["max_calculated_dp_pa"], expected)
        self.assertAlmostEqual(s["head_m"], expected / (977.81 * G))

    def test_incomplete_no_pump_head(self):
        p = demo_project()
        p["branches"][0]["path_complete"] = False
        s = calculate(p)["systems"][0]
        self.assertIsNone(s["head_m"])
        self.assertIsNone(s["critical_loop_id"])

    def test_flow_conversion(self):
        rho = 978
        self.s["rho"] = rho
        r = segment_loss(self.seg, 866 / 3600, self.s)
        self.assertAlmostEqual(r["flow_m3h"], 866 / rho)

    def test_no_temperature_difference(self):
        p = demo_project()
        p["systems"][0]["return_c"] = 80
        with self.assertRaises(InputError):
            calculate(p)

    def test_missing_inner_diameter(self):
        with self.assertRaises(InputError):
            segment_loss(dict(self.seg, inner_mm=0), 0.1, self.s)

    def test_nan_rejected(self):
        with self.assertRaises(InputError):
            number("NaN", "Input")

    def test_duplicate_path_rejected(self):
        p = demo_project()
        p["branches"][0]["main_path"] = ["M-подача", "M-подача"]
        with self.assertRaises(InputError):
            calculate(p)

    def test_cross_system_path_rejected(self):
        p = demo_project()
        p["systems"].append(default_system("2.1"))
        p["mains"][0]["system_id"] = "2.1"
        with self.assertRaises(InputError):
            calculate(p)

    def test_water_interpolation(self):
        props = water_properties(65)
        self.assertAlmostEqual(props["rho"], (983.24 + 977.81) / 2)

    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = demo_project()
            path = Path(d) / "Отопление.json"
            save_project(p, path)
            self.assertEqual(load_project(path), p)

    def test_template_import_repeat_idempotent(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "template.xlsx"
            create_template(path)
            p, w = import_table(empty_project(), path, "Ввод веток")
            self.assertEqual(len(p["branches"]), 2)
            self.assertEqual(len(p["segments"]), 2)
            p2, _ = import_table(p, path, "Ввод веток")
            self.assertEqual(len(p2["branches"]), 2)
            self.assertEqual(len(p2["segments"]), 2)
            self.assertEqual(calculate(p2)["branches"][0]["heat_w"], 1000)
            self.assertIsNone(calculate(p2)["systems"][0]["head_m"])

    def test_raw_export_does_not_sum_pieces_in_length(self):
        import openpyxl

        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "raw.xlsx"
            w = openpyxl.Workbook()
            s = w.active
            s.append(
                [
                    "1.Номер ветки",
                    "2.Номер системы",
                    "Количество",
                    "Единица измерения",
                    "Q, Вт (ввод в ручную)",
                ]
            )
            s.append(["101-1", "1.1", 2.7, "м", None])
            s.append(["101-1", "1.1", 4, "шт.", 1000])
            w.save(path)
            p, notes = import_table(empty_project(), path)
            self.assertEqual(sum(x["length_m"] for x in p["segments"]), 2.7)
            self.assertEqual(p["branches"][0]["heat_w"], 1000)
            self.assertEqual(p["segments"][0]["inner_mm"], 0)

    def test_nominal_diameter_not_inner(self):
        import openpyxl

        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "schedule.xlsx"
            w = openpyxl.Workbook()
            s = w.active
            s.append(["Номер ветки", "Длина", "Диаметр", "Мощность, Вт"])
            s.append(["101-1", 20, 16, 1000])
            w.save(path)
            p, notes = import_table(empty_project(), path)
            self.assertEqual(p["segments"][0]["inner_mm"], 0)
            self.assertTrue(any("внутренний диаметр" in n for n in notes))

    def test_formula_injection_export_literal(self):
        import openpyxl

        with tempfile.TemporaryDirectory() as d:
            p = demo_project()
            p["branches"][0]["name"] = "=1+2"
            path = Path(d) / "result.xlsx"
            export_results(calculate(p), path)
            w = openpyxl.load_workbook(path, data_only=False)
            c = next(c for row in w["Ветки"] for c in row if c.value == "=1+2")
            self.assertEqual(c.data_type, "s")


if __name__ == "__main__":
    unittest.main(verbosity=2)
