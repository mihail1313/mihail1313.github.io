"""Excel regressions: visible summaries, save failures and incomplete projects."""

import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import openpyxl

from excel_io import export_project, export_results, import_table
from hydraulics import InputError, calculate, demo_project, empty_project


class ExportV03(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.path = self.directory / "Гидравлика — результат.xlsx"

    def tearDown(self):
        self.temp.cleanup()

    def book(self):
        book = openpyxl.load_workbook(self.path, data_only=False)
        self.addCleanup(book.close)
        return book

    @staticmethod
    def original_project(book):
        return json.loads("".join(row[1] for row in list(book["Исходные данные JSON"].values)[1:]))

    @staticmethod
    def summary(book):
        return {(row[0], row[1]): row[2] for row in list(book["Сводка"].values)[1:]}

    def test_summary_separates_heat_maximum_and_hydraulic_critical_loop(self):
        project = demo_project()
        project["segments"][0]["length_m"] = 200
        result = calculate(project)
        system = result["systems"][0]
        self.assertNotEqual(system["most_loaded_branch_id"], system["critical_loop_id"])
        export_results(result, self.path)
        book = self.book()
        self.assertEqual(book.sheetnames[0], "Сводка")
        summary = self.summary(book)
        self.assertEqual(summary[("1.1", "Самая мощная ветка")], "101-2")
        self.assertEqual(summary[("1.1", "Диктующее кольцо")], "101-1")
        self.assertAlmostEqual(
            summary[("1.1", "101-1: сумма потерь кольца")],
            summary[("1.1", "101-1: потери ветки")] + summary[("1.1", "101-1: потери магистралей")],
        )
        self.assertEqual(book["Ветки"]["A2"].fill.fgColor.rgb, "00FFE1C2")
        self.assertEqual(book["Ветки"]["A3"].fill.fgColor.rgb, "00DCF2E1")

    def test_equal_heat_branches_are_all_visible(self):
        project = demo_project()
        project["branches"][0]["heat_w"] = project["branches"][1]["heat_w"]
        export_results(calculate(project), self.path)
        value = self.summary(self.book())[("1.1", "Самая мощная ветка")]
        self.assertEqual(set(value.split(", ")), {"101-1", "101-2"})

    def test_independent_system_flows_separate_without_combined_pump_head(self):
        project = demo_project()
        other = copy.deepcopy(project)
        other["systems"][0]["id"] = "2.1"
        other["systems"][0]["supply_c"] = 70
        for branch in other["branches"]:
            branch["id"] = "B-" + branch["id"]
            branch["system_id"] = "2.1"
            branch["main_path"] = ["B-" + identifier for identifier in branch["main_path"]]
        for segment in other["segments"]:
            segment["id"] = "B-" + segment["id"]
            segment["branch_id"] = "B-" + segment["branch_id"]
        for main in other["mains"]:
            main["id"] = "B-" + main["id"]
            main["system_id"] = "2.1"
        for key in ("systems", "branches", "segments", "mains"):
            project[key] += other[key]
        result = calculate(project)
        export_results(result, self.path)
        summary = self.summary(self.book())
        for system in result["systems"]:
            self.assertAlmostEqual(summary[(system["id"], "Расход системы")], system["flow_m3h"])
        self.assertAlmostEqual(
            summary[("Все системы", "Сумма расчётных расходов систем")],
            sum(system["flow_m3h"] for system in result["systems"]),
        )
        self.assertFalse(
            any(key[0] == "Все системы" and "напор" in key[1].lower() for key in summary)
        )

    def test_incomplete_path_exports_candidate_and_no_final_head(self):
        project = demo_project()
        project["branches"][0]["path_complete"] = False
        export_results(calculate(project), self.path)
        summary = self.summary(self.book())
        self.assertEqual(summary[("1.1", "Диктующее кольцо")], "Не определено")
        self.assertIsNone(summary[("1.1", "Расчётный напор")])
        self.assertIsNone(summary[("1.1", "Напор с запасами")])
        self.assertTrue(summary[("1.1", "Кандидаты по учтённым потерям")])

    def test_unknown_margin_law_keeps_design_result_and_blank_margin_head(self):
        project = demo_project()
        project["systems"][0]["flow_margin_percent"] = 10
        project["segments"][0]["extra_dp_pa"] = 1000
        project["segments"][0]["extra_model"] = "design"
        export_results(calculate(project), self.path)
        summary = self.summary(self.book())
        self.assertGreater(summary[("1.1", "Расчётный напор")], 0)
        self.assertIsNone(summary[("1.1", "Напор с запасами")])
        self.assertIn("закон", summary[("1.1", "Статус расчёта с запасом")])

    def test_draft_missing_diameter_and_heat_exports_exact_inputs_and_readiness(self):
        project = demo_project()
        project["segments"][0]["inner_mm"] = 0
        project["branches"][0]["heat_w"] = 0
        with patch("hydraulics.calculate", side_effect=AssertionError("must not calculate")):
            export_project(project, self.path)
        book = self.book()
        self.assertEqual(self.original_project(book), project)
        messages = " ".join(str(row[2]) for row in list(book["Готовность"].values)[1:])
        self.assertIn("диаметр", messages)
        self.assertIn("мощность", messages)
        self.assertNotIn("Системы", book.sheetnames)
        self.assertIn("не выполнен", book["Исходные данные"]["B3"].value)

    def test_empty_draft_can_be_exported(self):
        project = empty_project()
        export_project(project, self.path)
        book = self.book()
        self.assertEqual(self.original_project(book), project)
        self.assertIn("Нет веток", book["Готовность"]["C2"].value)

    def test_draft_segment_sheet_can_be_imported_as_branch_table(self):
        project = demo_project()
        export_project(project, self.path)
        imported, warnings = import_table(empty_project(), self.path, sheet="Ввод участков")
        self.assertEqual(len(imported["branches"]), len(project["branches"]))
        self.assertEqual(len(imported["segments"]), len(project["segments"]))
        self.assertAlmostEqual(
            sum(segment["length_m"] for segment in imported["segments"]),
            sum(segment["length_m"] for segment in project["segments"]),
        )
        self.assertEqual(
            sorted(segment["inner_mm"] for segment in imported["segments"]),
            sorted(segment["inner_mm"] for segment in project["segments"]),
        )

    def test_formula_text_is_literal_and_negative_temperature_stays_numeric(self):
        project = demo_project()
        project["name"] = '=HYPERLINK("https://example.test", "click")'
        project["branches"][0]["name"] = "=1+2"
        project["systems"][0].update(properties_mode="manual", supply_c=5, return_c=-5)
        export_project(project, self.path)
        book = self.book()
        formula_text_cells = [
            cell
            for sheet in book
            for row in sheet
            for cell in row
            if isinstance(cell.value, str) and cell.value.startswith("=")
        ]
        self.assertTrue(formula_text_cells)
        self.assertTrue(all(cell.data_type == "s" for cell in formula_text_cells))
        columns = {cell.value: cell.column for cell in book["Ввод систем"][1]}
        temperature = book["Ввод систем"].cell(2, columns["Обратка, °C"])
        self.assertEqual(temperature.value, -5)
        self.assertEqual(temperature.data_type, "n")

    def test_control_characters_and_long_names_export_without_loss_in_json(self):
        project = demo_project()
        project["name"] = "Название\x00с\uffffсимволами"
        project["branches"][0]["name"] = "Радиатор\x0b" + "А" * 40000
        export_results(calculate(project), self.path)
        book = self.book()
        self.assertEqual(self.original_project(book), project)
        names = [cell.value for row in book["Ветки"] for cell in row if isinstance(cell.value, str)]
        self.assertTrue(any("полное значение" in value for value in names))
        self.assertIn("\\u0000", book["Сводка"]["C2"].value)

    def test_locked_existing_workbook_stays_intact_and_error_is_actionable(self):
        export_results(calculate(demo_project()), self.path)
        original = self.path.read_bytes()
        with patch("hydraulics.os.replace", side_effect=PermissionError("sharing violation")):
            with self.assertRaisesRegex(InputError, "Закройте этот файл в Excel"):
                export_project(empty_project(), self.path)
        self.assertEqual(self.path.read_bytes(), original)
        self.assertFalse(list(self.directory.glob("*.tmp")))

    def test_missing_folder_error_explains_save_problem(self):
        with self.assertRaisesRegex(InputError, "Не удалось сохранить Excel"):
            export_project(empty_project(), self.directory / "missing" / "output.xlsx")

    def test_successful_overwrite_keeps_previous_workbook_backup(self):
        export_results(calculate(demo_project()), self.path)
        original = self.path.read_bytes()
        export_project(empty_project(), self.path)
        self.assertEqual(self.path.with_name(self.path.name + ".bak").read_bytes(), original)
        self.assertNotEqual(self.path.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
