import copy, tempfile, unittest
from pathlib import Path
import openpyxl
from hydraulics import calculate, demo_project, default_system, InputError, number, segment_loss
from excel_io import import_table
from project_ops import bulk_update


class FinalChecks(unittest.TestCase):
    def test_new_source_column_conflicts_with_manual_override(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "table.xlsx"

            def write(extra=False):
                w = openpyxl.Workbook()
                s = w.active
                s.append(["Номер ветки", "Длина, м", "ID участка"] + (["КМС"] if extra else []))
                s.append(["101-1", 10, "A"] + ([3] if extra else []))
                w.save(path)
                w.close()

            write()
            p, _ = import_table(demo_project(), path)
            imported = next(s for s in p["segments"] if "_import" in s)
            imported["zeta"] = 8
            write(True)
            with self.assertRaisesRegex(InputError, "конфликт"):
                import_table(p, path)

    def test_partial_common_main_flow(self):
        p = demo_project()
        p["branches"][0]["main_path"] = ["M-подача"]
        r = calculate(p)
        self.assertAlmostEqual(r["mains"][0]["flow_m3h"], sum(b["flow_m3h"] for b in r["branches"]))
        self.assertAlmostEqual(r["mains"][1]["flow_m3h"], r["branches"][1]["flow_m3h"])

    def test_independent_systems(self):
        p = demo_project()
        second = copy.deepcopy(p)
        second["systems"][0]["id"] = "2.1"
        for b in second["branches"]:
            b["system_id"] = "2.1"
            b["id"] = "S2-" + b["id"]
            b["main_path"] = ["S2-" + m for m in b["main_path"]]
        for s in second["segments"]:
            s["id"] = "S2-" + s["id"]
            s["branch_id"] = "S2-" + s["branch_id"]
        for m in second["mains"]:
            m["id"] = "S2-" + m["id"]
            m["system_id"] = "2.1"
        for key in ("systems", "branches", "segments", "mains"):
            p[key] += second[key]
        r = calculate(p)
        self.assertEqual(len(r["systems"]), 2)
        self.assertAlmostEqual(r["systems"][0]["flow_m3h"], r["systems"][1]["flow_m3h"])
        self.assertAlmostEqual(r["systems"][0]["head_m"], r["systems"][1]["head_m"])

    def test_missing_branch_never_omitted_from_total(self):
        p = demo_project()
        p["branches"][0]["heat_w"] = 0
        with self.assertRaises(InputError):
            calculate(p)

    def test_subnormal_numbers_fail_cleanly(self):
        p = demo_project()
        p["branches"][0]["heat_w"] = 1e-300
        with self.assertRaises(InputError):
            calculate(p)
        with self.assertRaises(InputError):
            segment_loss(p["segments"][0], 1e-300, default_system())

    def test_route_edit_removes_old_complete_confirmation(self):
        p = bulk_update(demo_project(), "branches", [0], "main_path", ["M-подача"])
        self.assertFalse(p["branches"][0]["path_complete"])

    def test_all_input_rows_order_invariant(self):
        p = demo_project()
        a = calculate(p)
        for key in ("systems", "branches", "segments", "mains"):
            p[key].reverse()
        b = calculate(p)
        self.assertAlmostEqual(a["systems"][0]["head_m"], b["systems"][0]["head_m"])
        self.assertAlmostEqual(a["systems"][0]["flow_m3h"], b["systems"][0]["flow_m3h"])


if __name__ == "__main__":
    unittest.main()
