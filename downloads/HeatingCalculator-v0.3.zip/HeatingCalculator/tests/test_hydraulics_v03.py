"""Independent examples for pump-circuit scope and visible branch maxima."""

import copy
import unittest

from hydraulics import G, InputError, calculate, default_system, empty_project, segment_loss


def pressure_example():
    """Known losses isolate route accounting from pipe-friction approximation."""
    project = empty_project()
    project["systems"][0].update(
        properties_mode="manual", rho=1000, cp=4000, nu_mm2_s=1, supply_c=70, return_c=50
    )
    for bid, heat, pressure, path in [
        ("101-1", 1000, 100, ["S", "long-feed", "R"]),
        ("101-2", 2000, 200, ["S", "R"]),
    ]:
        project["branches"].append(
            {
                "id": bid,
                "name": bid,
                "system_id": "1.1",
                "collector_id": "101",
                "heat_w": heat,
                "main_path": path,
                "path_complete": True,
            }
        )
        project["segments"].append(
            {
                "id": "pipe-" + bid,
                "branch_id": bid,
                "length_m": 0,
                "inner_mm": 20,
                "zeta": 0,
                "extra_dp_pa": pressure,
                "extra_model": "quadratic",
            }
        )
    for mid, pressure in [("S", 50), ("long-feed", 500), ("R", 70)]:
        project["mains"].append(
            {
                "id": mid,
                "system_id": "1.1",
                "name": mid,
                "length_m": 0,
                "inner_mm": 25,
                "zeta": 0,
                "extra_dp_pa": pressure,
                "extra_model": "quadratic",
            }
        )
    return project


class HydraulicScopeV03(unittest.TestCase):
    def test_max_heat_max_branch_pressure_and_critical_ring_are_distinct(self):
        result = calculate(pressure_example())
        system = result["systems"][0]
        branches = {b["id"]: b for b in result["branches"]}
        self.assertEqual(system["most_loaded_branch_ids"], ["101-2"])
        self.assertEqual(system["most_loaded_branch_heat_w"], 2000)
        self.assertEqual(system["highest_flow_branch_ids"], ["101-2"])
        self.assertAlmostEqual(system["highest_branch_flow_m3h"], 0.09)
        self.assertEqual(system["max_branch_ids"], ["101-2"])
        self.assertEqual(system["max_branch_dp_pa"], 200)
        self.assertEqual(system["critical_loop_ids"], ["101-1"])
        self.assertEqual(branches["101-1"]["main_dp_pa"], 620)
        self.assertEqual(branches["101-1"]["loop_dp_pa"], 720)
        self.assertEqual(branches["101-2"]["main_dp_pa"], 120)
        self.assertEqual(branches["101-2"]["loop_dp_pa"], 320)
        self.assertTrue(branches["101-1"]["is_critical_loop"])
        self.assertFalse(branches["101-1"]["is_most_loaded"])
        self.assertTrue(branches["101-2"]["is_most_loaded"])
        self.assertTrue(branches["101-2"]["is_max_branch_loss"])
        self.assertFalse(branches["101-2"]["is_critical_loop"])
        self.assertEqual(branches["101-2"]["balance_dp_pa"], 400)
        self.assertAlmostEqual(system["head_m"], 720 / (1000 * G))

    def test_shared_equipment_uses_total_flow_and_each_loop_counts_it_once(self):
        project = pressure_example()
        # One shared valve Kv=1: dp = (0.135 m3/h)^2 * 100000 = 1822.5 Pa.
        project["mains"][0].update(extra_dp_pa=0, kv_m3h=1)
        # Valve on the first path only sees 0.045 m3/h, giving 202.5 Pa.
        project["mains"][1].update(extra_dp_pa=0, kv_m3h=1)
        result = calculate(project)
        mains = {m["id"]: m for m in result["mains"]}
        branches = {b["id"]: b for b in result["branches"]}
        self.assertAlmostEqual(mains["S"]["flow_m3h"], 0.135)
        self.assertAlmostEqual(mains["R"]["flow_m3h"], 0.135)
        self.assertAlmostEqual(mains["long-feed"]["flow_m3h"], 0.045)
        self.assertAlmostEqual(mains["S"]["dp_kv_pa"], 1822.5)
        self.assertAlmostEqual(mains["long-feed"]["dp_kv_pa"], 202.5)
        self.assertAlmostEqual(branches["101-1"]["loop_dp_pa"], 100 + 1822.5 + 202.5 + 70)
        self.assertAlmostEqual(branches["101-2"]["loop_dp_pa"], 200 + 1822.5 + 70)
        self.assertAlmostEqual(result["systems"][0]["flow_m3h"], 0.135)
        self.assertAlmostEqual(result["totals"]["flow_m3h"], 0.135)

    def test_all_tied_ids_and_flags_are_retained(self):
        project = pressure_example()
        project["branches"][1].update(heat_w=1000, main_path=["S", "long-feed", "R"])
        project["segments"][1]["extra_dp_pa"] = 100
        result = calculate(project)
        system = result["systems"][0]
        for key in (
            "most_loaded_branch_ids",
            "highest_flow_branch_ids",
            "max_branch_ids",
            "candidate_loop_ids",
            "critical_loop_ids",
            "margin_candidate_loop_ids",
            "margin_critical_loop_ids",
        ):
            self.assertEqual(set(system[key]), {"101-1", "101-2"}, key)
        for branch in result["branches"]:
            for flag in (
                "is_most_loaded",
                "is_highest_flow",
                "is_max_branch_loss",
                "is_candidate_loop",
                "is_critical_loop",
            ):
                self.assertTrue(branch[flag], flag)

    def test_incomplete_system_keeps_candidates_but_never_labels_final_critical(self):
        project = pressure_example()
        project["branches"][1]["path_complete"] = False
        project["systems"][0]["flow_margin_percent"] = 20
        result = calculate(project)
        system = result["systems"][0]
        self.assertEqual(system["candidate_loop_ids"], ["101-1"])
        self.assertEqual(system["margin_candidate_loop_ids"], ["101-1"])
        self.assertEqual(system["critical_loop_ids"], [])
        self.assertEqual(system["margin_critical_loop_ids"], [])
        self.assertIsNone(system["head_m"])
        self.assertIsNone(system["head_with_margin_m"])
        self.assertTrue(result["branches"][0]["is_candidate_loop"])
        self.assertTrue(all(not b["is_critical_loop"] for b in result["branches"]))
        self.assertEqual(system["most_loaded_branch_ids"], ["101-2"])

    def test_margin_pressure_sums_main_and_branch_before_head_margin(self):
        project = pressure_example()
        project["systems"][0].update(flow_margin_percent=20, head_margin_percent=10)
        system = calculate(project)["systems"][0]
        self.assertAlmostEqual(system["flow_with_margin_m3h"], 0.135 * 1.2)
        self.assertAlmostEqual(system["dp_at_increased_flow_pa"], 720 * 1.2**2)
        self.assertAlmostEqual(system["head_with_margin_m"], 720 * 1.2**2 * 1.1 / (1000 * G))

    def test_independent_systems_keep_own_delta_t_and_no_project_pump_head(self):
        project = pressure_example()
        second = copy.deepcopy(project)
        second["systems"][0].update(id="2.1", supply_c=65, return_c=55)
        for b in second["branches"]:
            b.update(
                id="B-" + b["id"], system_id="2.1", main_path=["B-" + m for m in b["main_path"]]
            )
        for segment in second["segments"]:
            segment.update(id="B-" + segment["id"], branch_id="B-" + segment["branch_id"])
        for main in second["mains"]:
            main.update(id="B-" + main["id"], system_id="2.1")
        for key in ("systems", "branches", "segments", "mains"):
            project[key].extend(second[key])
        result = calculate(project)
        systems = {s["id"]: s for s in result["systems"]}
        self.assertAlmostEqual(systems["1.1"]["flow_m3h"], 0.135)
        self.assertAlmostEqual(systems["2.1"]["flow_m3h"], 0.27)
        self.assertEqual(result["totals"]["heat_w"], 6000)
        self.assertAlmostEqual(result["totals"]["flow_m3h"], 0.405)
        self.assertAlmostEqual(result["totals"]["mass_kgh"], 405)
        self.assertEqual(result["totals"]["system_count"], 2)
        self.assertEqual(result["totals"]["branch_count"], 4)
        self.assertEqual(result["totals"]["flow_scope"], "sum_of_system_design_flows")
        self.assertNotIn("head_m", result["totals"])
        self.assertNotIn("head_with_margin_m", result["totals"])

    def test_duplicate_route_never_counts_an_element_twice(self):
        project = pressure_example()
        project["branches"][0]["main_path"].append("S")
        with self.assertRaisesRegex(InputError, "повторяется"):
            calculate(project)

    def test_returned_route_is_independent_from_project(self):
        project = pressure_example()
        before = copy.deepcopy(project)
        result = calculate(project)
        result["branches"][0]["main_path"].clear()
        self.assertEqual(project, before)

    def test_zero_flow_needs_no_unknown_equipment_curve(self):
        segment = pressure_example()["segments"][0]
        segment["extra_model"] = "design"
        result = segment_loss(segment, 0, default_system(), flow_factor=1.2)
        self.assertEqual(result["dp_pa"], 0)


if __name__ == "__main__":
    unittest.main()
