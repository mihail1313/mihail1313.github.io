import copy, json, math, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import openpyxl
from hydraulics import *
from excel_io import import_table, read_rows, create_template, export_results
from project_ops import edit_row, delete_rows, bulk_update, History


class Engineering(unittest.TestCase):
    def test_water_updates_on_temperature_edit(self):
        p = demo_project()
        p["systems"][0].update(supply_c=60, return_c=40, rho=1, cp=1, nu_mm2_s=1)
        s = calculate(p)["systems"][0]
        self.assertEqual(s["rho"], 988)
        self.assertEqual(s["cp"], 4181)

    def test_legacy_explicit_properties_unchanged(self):
        p = demo_project()
        p["systems"][0].pop("properties_mode")
        p["systems"][0]["rho"] = 999
        self.assertEqual(calculate(p)["systems"][0]["rho"], 999)

    def test_flow_margin_recomputes_pressure(self):
        p = demo_project()
        p["systems"][0]["flow_margin_percent"] = 20
        s = calculate(p)["systems"][0]
        other = copy.deepcopy(p)
        other["systems"][0]["flow_margin_percent"] = 0
        for b in other["branches"]:
            b["heat_w"] *= 1.2
        expected = calculate(other)["systems"][0]
        self.assertAlmostEqual(s["head_with_margin_m"], expected["head_m"])
        self.assertGreater(s["head_with_margin_m"], s["head_m"])

    def test_unknown_extra_loss_curve_blocks_margin_only(self):
        p = demo_project()
        p["systems"][0]["flow_margin_percent"] = 10
        p["segments"][0]["extra_dp_pa"] = 1000
        s = calculate(p)["systems"][0]
        self.assertIsNotNone(s["head_m"])
        self.assertIsNone(s["head_with_margin_m"])

    def test_extra_quadratic_scaling(self):
        s = default_system()
        seg = dict(
            demo_project()["segments"][0],
            length_m=0,
            zeta=0,
            extra_dp_pa=1000,
            extra_model="quadratic",
        )
        self.assertAlmostEqual(segment_loss(seg, 0.03, s, 1.2)["dp_pa"], 1440)

    def test_tied_critical_rings_and_balance(self):
        p = demo_project()
        p["branches"][1]["heat_w"] = 1000
        p["segments"][1]["length_m"] = 20
        r = calculate(p)
        self.assertEqual(len(r["systems"][0]["critical_loop_ids"]), 2)
        self.assertTrue(all(b["balance_dp_pa"] == 0 for b in r["branches"]))

    def test_unused_main_prevents_false_completeness(self):
        p = demo_project()
        p["mains"].append(dict(p["mains"][0], id="Unused"))
        self.assertIsNone(calculate(p)["systems"][0]["head_m"])

    def test_collector_totals(self):
        r = calculate(demo_project())
        self.assertEqual(r["collectors"][0]["heat_w"], 2500)
        self.assertEqual(r["collectors"][0]["length_m"], 55)

    def test_readiness_lists_all_missing(self):
        p = demo_project()
        for b in p["branches"]:
            b["heat_w"] = 0
        for s in p["segments"]:
            s["inner_mm"] = 0
        self.assertEqual(sum(i["severity"] == "error" for i in readiness(p)), 4)

    def test_no_mutation_during_calculate(self):
        p = demo_project()
        old = copy.deepcopy(p)
        calculate(p)
        self.assertEqual(p, old)

    def test_extreme_inputs_controlled(self):
        for v in (float("inf"), 1e308, -1, True, {}, None):
            with self.subTest(v=v), self.assertRaises(InputError):
                number(v, "test")

    def test_high_velocity_controlled(self):
        seg = dict(demo_project()["segments"][0], inner_mm=0.1)
        with self.assertRaises(InputError):
            segment_loss(seg, 1, default_system())

    def test_invalid_ids_and_path_do_not_typeerror(self):
        for v in (None, 1, " 1 ", {}, [], True):
            p = demo_project()
            p["branches"][0]["main_path"] = [v]
            with self.subTest(v=v), self.assertRaises(InputError):
                validate_project(p)

    def test_invalid_numeric_draft_not_saved(self):
        p = demo_project()
        p["segments"][0]["length_m"] = "wrong"
        with self.assertRaises(InputError):
            validate_project(p)

    def test_zero_diameter_can_be_saved_as_draft(self):
        p = demo_project()
        p["segments"][0]["inner_mm"] = 0
        validate_project(p)
        with self.assertRaises(InputError):
            calculate(p)

    def test_bad_edit_transactional(self):
        p = demo_project()
        old = copy.deepcopy(p)
        b = dict(p["branches"][0], system_id="Missing")
        with self.assertRaises(InputError):
            edit_row(p, "branches", 0, b)
        self.assertEqual(p, old)

    def test_rename_cascades(self):
        p = demo_project()
        p = edit_row(p, "branches", 0, dict(p["branches"][0], id="New"))
        self.assertEqual(p["segments"][0]["branch_id"], "New")

    def test_delete_invalidate_completeness(self):
        p = delete_rows(demo_project(), "segments", [0])
        self.assertFalse(p["branches"][0]["path_complete"])

    def test_bulk_and_undo(self):
        p = demo_project()
        h = History()
        h.push(p)
        new = bulk_update(p, "segments", [0, 1], "inner_mm", 12)
        self.assertTrue(all(s["inner_mm"] == 12 for s in new["segments"]))
        self.assertEqual(h.undo(new), p)
        self.assertEqual(h.redo(p), new)

    def test_churchill_against_colebrook(self):
        # Independent fixed-point Colebrook solution; Churchill is an approximation.
        s = default_system()
        s.update(rho=1000, nu_mm2_s=1)
        for re in (1e4, 1e5, 1e6):
            for relative in (0, 0.0001, 0.001, 0.01):
                seg = {"id": "s", "length_m": 1, "inner_mm": 100, "roughness_mm": relative * 100}
                mass = re * 1e-6 / 0.1 * 1000 * math.pi * 0.1**2 / 4
                got = segment_loss(seg, mass, s)["lambda"]
                f = 0.02
                for _ in range(100):
                    f = 1 / (-2 * math.log10(relative / 3.7 + 2.51 / (re * math.sqrt(f)))) ** 2
                self.assertLess(abs(got - f) / f, 0.035, (re, relative, got, f))


class Storage(unittest.TestCase):
    def test_save_backup_and_external_change(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "p.json"
            p = demo_project()
            save_project(p, path)
            first = path.read_bytes()
            digest = file_digest(path)
            p["name"] = "changed"
            save_project(p, path, expected_digest=digest)
            self.assertEqual(path.with_name("p.json.bak").read_bytes(), first)
            with self.assertRaises(InputError):
                save_project(p, path, expected_digest=digest)

    def test_failed_replace_preserves_file(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "p.json"
            save_project(demo_project(), path)
            old = path.read_bytes()
            with patch("hydraulics.os.replace", side_effect=OSError("locked")):
                with self.assertRaises(OSError):
                    save_project(empty_project(), path)
            self.assertEqual(path.read_bytes(), old)
            self.assertFalse(list(Path(d).glob("*.tmp")))

    def test_json_duplicate_key_and_nan_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "p.json"
            for s in ('{"schema_version":1,"schema_version":1}', '{"x":NaN}'):
                p.write_text(s)
                with self.assertRaises(InputError):
                    load_project(p)

    def test_full_export_source_is_reconstructible(self):
        with tempfile.TemporaryDirectory() as d:
            p = demo_project()
            p["notes"] = "X" * 70000
            r = calculate(p)
            path = Path(d) / "r.xlsx"
            export_results(r, path)
            w = openpyxl.load_workbook(path, read_only=True)
            raw = "".join(row[1] for row in list(w["Исходные данные JSON"].values)[1:])
            self.assertEqual(json.loads(raw), p)
            w.close()


class Importing(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "input.xlsx"

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, headers, rows):
        w = openpyxl.Workbook()
        s = w.active
        s.append(headers)
        for row in rows:
            s.append(row)
        w.save(self.path)
        w.close()

    def basics(self):
        return ["Номер ветки", "Длина, м", "Внутренний диаметр, мм", "Мощность, Вт", "ID участка"]

    def test_reorder_keeps_manual_diameter(self):
        h = self.basics()
        self.write(h, [["101-1", 10, 10, 1000, "a"], ["101-1", 20, 10, 1000, "b"]])
        p, _ = import_table(empty_project(), self.path)
        p["segments"][0]["inner_mm"] = 15
        self.write(h, [["101-1", 20, 10, 1000, "b"], ["101-1", 10, 10, 1000, "a"]])
        p, _ = import_table(p, self.path)
        self.assertEqual(
            next(s for s in p["segments"] if s["source"]["external_id"] == "a")["inner_mm"], 15
        )

    def test_missing_columns_preserve_resistances(self):
        self.write(self.basics(), [["101-1", 10, 10, 1000, "a"]])
        p, _ = import_table(empty_project(), self.path)
        p["segments"][0].update(zeta=8, kv_m3h=1.3, extra_dp_pa=100)
        p, _ = import_table(p, self.path)
        self.assertEqual(p["segments"][0]["zeta"], 8)
        self.assertEqual(p["segments"][0]["kv_m3h"], 1.3)

    def test_deleted_rows_removed_only_from_source(self):
        h = self.basics()
        self.write(h, [["101-1", 10, 10, 1000, "a"], ["101-1", 20, 10, 1000, "b"]])
        p, _ = import_table(empty_project(), self.path)
        p["segments"].append(dict(p["segments"][0], id="Manual", _import={}))
        self.write(h, [["101-1", 10, 10, 1000, "a"]])
        p, _ = import_table(p, self.path)
        self.assertEqual(len(p["segments"]), 2)
        self.assertEqual(sum(s["length_m"] for s in p["segments"]), 20)

    def test_conflict_rejected_no_partial_change(self):
        self.write(self.basics(), [["101-1", 10, 10, 1000, "a"]])
        p, _ = import_table(empty_project(), self.path)
        p["segments"][0]["inner_mm"] = 15
        old = copy.deepcopy(p)
        self.write(self.basics(), [["101-1", 10, 20, 1000, "a"]])
        with self.assertRaises(InputError):
            import_table(p, self.path)
        self.assertEqual(p, old)

    def test_renamed_file_explicit_source(self):
        create_template(self.path)
        p, _ = import_table(empty_project(), self.path)
        self.path.rename(self.path.with_name("new.xlsx"))
        self.path = self.path.with_name("new.xlsx")
        p, _ = import_table(p, self.path, source_id=p["imports"][0]["id"])
        self.assertEqual(len(p["segments"]), 2)

    def test_csv_multiline_and_decimal_comma(self):
        p = Path(self.tmp.name) / "x.csv"
        p.write_text(
            'Номер ветки;Длина, м;Наименование\n101-1;"2,7";"Радиатор\nКомната"\n',
            encoding="utf-8-sig",
        )
        data, _ = import_table(empty_project(), p)
        self.assertEqual(data["segments"][0]["length_m"], 2.7)
        self.assertIn("\n", data["branches"][0]["name"])

    def test_revit_utf16_tabs(self):
        p = Path(self.tmp.name) / "x.txt"
        p.write_text("Номер ветки\tДлина, м\n101-1\t2,7\n", encoding="utf-16")
        data, _ = import_table(empty_project(), p)
        self.assertEqual(data["segments"][0]["length_m"], 2.7)

    def test_cp1251(self):
        p = Path(self.tmp.name) / "x.csv"
        p.write_bytes("Номер ветки;Длина, м\n101-1;2\n".encode("cp1251"))
        data, _ = import_table(empty_project(), p)
        self.assertEqual(len(data["segments"]), 1)

    def test_explicit_units(self):
        self.write(
            [
                "Номер ветки",
                "Длина, мм",
                "Внутренний диаметр, м",
                "Мощность, кВт",
                "Доп. потери, кПа",
            ],
            [["101-1", 1200, 0.012, 1.5, 2]],
        )
        p, _ = import_table(empty_project(), self.path)
        self.assertEqual(p["branches"][0]["heat_w"], 1500)
        s = p["segments"][0]
        self.assertEqual(s["length_m"], 1.2)
        self.assertEqual(s["inner_mm"], 12)
        self.assertEqual(s["extra_dp_pa"], 2000)

    def test_resistance_only_row_imported(self):
        self.write(["Номер ветки", "Kv", "Внутренний диаметр, мм"], [["101-1", 1, 10]])
        p, _ = import_table(empty_project(), self.path)
        self.assertEqual(p["segments"][0]["length_m"], 0)
        self.assertEqual(p["segments"][0]["kv_m3h"], 1)

    def test_formula_without_cache_not_silently_zero(self):
        self.write(self.basics(), [["101-1", "=5+5", 10, 1000, "a"]])
        with self.assertRaisesRegex(InputError, "сохранённого результата"):
            import_table(empty_project(), self.path)

    def test_excel_error_rejected(self):
        self.write(self.basics(), [["101-1", "#REF!", 10, 1000, "a"]])
        with self.assertRaisesRegex(InputError, "Ошибка Excel"):
            import_table(empty_project(), self.path)

    def test_ambiguous_columns_rejected(self):
        self.write(["Номер ветки", "Длина", "Длина, м"], [["101-1", 1, 2]])
        with self.assertRaisesRegex(InputError, "Неоднозначные"):
            import_table(empty_project(), self.path)

    def test_duplicate_external_ids_rejected(self):
        self.write(self.basics(), [["101-1", 10, 10, 1000, "a"], ["101-1", 20, 10, 1000, "a"]])
        with self.assertRaisesRegex(InputError, "Повтор ID"):
            import_table(empty_project(), self.path)

    def test_missing_source_power_does_not_remain_stale(self):
        self.write(self.basics(), [["101-1", 10, 10, 1000, "a"], ["101-2", 20, 10, 2000, "b"]])
        p, _ = import_table(empty_project(), self.path)
        self.write(self.basics(), [["101-1", 10, 10, 1000, "a"]])
        p, _ = import_table(p, self.path)
        self.assertEqual(p["branches"][1]["heat_w"], 0)

    def test_raw_power_semantics_explicit(self):
        self.write(
            ["Номер ветки", "Количество", "Единица измерения", "Q, Вт"], [["101-1", 2, "шт.", 1000]]
        )
        p, _ = import_table(empty_project(), self.path)
        self.assertEqual(p["branches"][0]["heat_w"], 1000)
        p, _ = import_table(empty_project(), self.path, heat_basis="per_item")
        self.assertEqual(p["branches"][0]["heat_w"], 2000)

    def test_same_data_copy_recognised(self):
        create_template(self.path)
        p, _ = import_table(empty_project(), self.path)
        second = self.path.with_name("copy.xlsx")
        second.write_bytes(self.path.read_bytes())
        p, _ = import_table(p, second)
        self.assertEqual(len(p["segments"]), 2)


if __name__ == "__main__":
    unittest.main()
