"""Exercise actual Tk widgets including import preview, bulk changes, validation and undo."""

import copy, sys, tempfile, os
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import App, Editor, CHOICES
from hydraulics import demo_project, load_project
from excel_io import create_template
from tkinter import ttk, Toplevel


def descendants(widget):
    for c in widget.winfo_children():
        yield c
        yield from descendants(c)


def button(widget, title):
    return next(
        w for w in descendants(widget) if isinstance(w, ttk.Button) and str(w["text"]) == title
    )


def dialog(app):
    return next(w for w in app.winfo_children() if isinstance(w, Toplevel))


with tempfile.TemporaryDirectory() as folder:
    os.environ["LOCALAPPDATA"] = folder
    app = App()
    app.project = demo_project()
    app.refresh()
    app.run()
    app.update()
    assert len(app.details_tree.get_children()) == 4
    assert len(app.collector_tree.get_children()) == 1
    editor = Editor(app, "systems", app.project["systems"][0], lambda r: None)
    editor.values["supply_c"].set("60")
    editor.values["return_c"].set("40")
    app.update()
    assert float(editor.values["rho"].get()) == 988
    assert str(editor.widgets["rho"]["state"]) == "readonly"
    editor.values["properties_mode"].set(CHOICES["mode"]["manual"])
    app.update()
    assert str(editor.widgets["rho"]["state"]) == "normal"
    editor.destroy()
    # A rejected edit leaves the editor open and the original data intact.
    app.trees["branches"].selection_set("0")
    before = copy.deepcopy(app.project)
    app.edit("branches", True)
    ed = dialog(app)
    ed.values["system_id"].set("Missing")
    with patch("app.messagebox.showerror") as show:
        ed.commit()
        assert show.called
    assert app.project == before
    ed.destroy()
    # Bulk edits through real dialog, then undo/redo and reset stale results.
    app.trees["segments"].selection_set("0", "1")
    app.bulk("segments")
    d = dialog(app)
    entry = next(
        w for w in descendants(d) if isinstance(w, ttk.Entry) and not isinstance(w, ttk.Combobox)
    )
    entry.insert(0, "12,5")
    button(d, "Применить").invoke()
    app.update()
    assert all(s["inner_mm"] == 12.5 for s in app.project["segments"])
    assert app.result is None
    assert not app.result_tree.get_children()
    assert not app.collector_tree.get_children()
    app.undo()
    assert app.project == before
    app.redo()
    assert app.project["segments"][0]["inner_mm"] == 12.5
    assert load_project(app.autosave_path) == app.project
    # Filtering does not change index mapping.
    app.filters["segments"].set("101-2")
    app.update()
    assert app.trees["segments"].get_children() == ("1",)
    app.filters["segments"].set("")
    # Import is transactional until Apply; changing sheet/options invalidates preview.
    path = Path(folder) / "template.xlsx"
    create_template(path)
    with patch("app.filedialog.askopenfilename", return_value=str(path)):
        app.import_excel()
    d = dialog(app)
    original = copy.deepcopy(app.project)
    button(d, "Проверить файл").invoke()
    app.update()
    assert app.project == original
    assert "disabled" not in button(d, "Применить импорт").state()
    combos = [w for w in descendants(d) if isinstance(w, ttk.Combobox)]
    combos[-1].set("Мощность одного прибора × количество")
    app.update()
    assert "disabled" in button(d, "Применить импорт").state()
    button(d, "Проверить файл").invoke()
    button(d, "Применить импорт").invoke()
    app.update()
    assert len(app.project["imports"]) == 1
    app.undo()
    assert app.project == original
    # Missing diameter removes any old numeric results, all omissions listed together.
    app.project["segments"][0]["inner_mm"] = 0
    app.run()
    app.update()
    assert app.result is None
    assert not app.details_tree.get_children()
    assert app.issue_tree.get_children()
    app.destroy()
print(
    "UI REGRESSION OK: automatic water, rejected edit, bulk edit, undo/redo, autosave, filter, import preview, stale results."
)
