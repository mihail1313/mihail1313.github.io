"""Run on Windows or Linux with DISPLAY; no external Revit needed."""

import sys, tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from unittest.mock import patch
from app import App, Editor
from hydraulics import demo_project, load_project

app = App()
app.project = demo_project()
app.refresh()
app.run()
app.update()
assert len(app.result_tree.get_children()) == 2
assert app.result["systems"][0]["critical_loop_id"] == "101-2"
for key in ("systems", "branches", "segments", "mains"):
    editor = Editor(app, key, app.project[key][0], lambda row: None)
    editor.update()
    if key == "systems":
        editor.water()
    editor.destroy()
with tempfile.TemporaryDirectory() as temp:
    target = Path(temp) / "project.json"
    with patch("app.filedialog.asksaveasfilename", return_value=str(target)):
        assert app.save()
    assert load_project(target) == app.project
    export = Path(temp) / "result.xlsx"
    with patch("app.filedialog.asksaveasfilename", return_value=str(export)):
        app.export()
    assert export.stat().st_size > 1000
    template = Path(temp) / "template.xlsx"
    with patch("app.filedialog.asksaveasfilename", return_value=str(template)):
        app.template()
    assert template.exists()
app.destroy()
print("UI OK: window, 4 editors, calculation, saving JSON, exporting Excel, template.")
