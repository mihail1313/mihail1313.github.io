"""Actual Tk integration for visible results, Excel export and built-in help."""

import copy
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import openpyxl
from tkinter import font as tkfont
from app import App
from hydraulics import demo_project


def visible_toolbar(app):
    app.update()
    for button in app.action_bar.buttons:
        assert button.winfo_ismapped(), button["text"]
        assert button.winfo_x() >= 0, button["text"]
        assert button.winfo_x() + button.winfo_width() <= app.action_bar.winfo_width(), button[
            "text"
        ]
        assert button.winfo_y() + button.winfo_height() <= app.action_bar.winfo_height(), button[
            "text"
        ]


with tempfile.TemporaryDirectory(prefix="heating-ui-v03-") as temp:
    os.environ["LOCALAPPDATA"] = temp
    app = App()
    app.geometry("960x640")
    app.project = demo_project()
    # Highest thermal load and highest hydraulic loss must be distinct here.
    app.project["segments"][0]["length_m"] = 200
    app.refresh()
    visible_toolbar(app)
    folder = Path(temp) / "Проверка экспорта — кириллица"
    folder.mkdir()
    target = folder / "Отопление.xlsx"
    assert app.result is None
    with patch("app.filedialog.asksaveasfilename", return_value=str(target)):
        export_button = next(b for b in app.action_bar.buttons if b["text"] == "Экспорт в Excel")
        export_button.invoke()
    app.update()
    assert target.exists(), "Export action must calculate and save, without requiring prior Run."
    assert app.result["systems"][0]["most_loaded_branch_ids"] == ["101-2"]
    assert app.result["systems"][0]["critical_loop_ids"] == ["101-1"]
    text = app.summary.get("1.0", "end")
    assert "Самая мощная ветка: 101-2" in text
    assert "Диктующее кольцо: 101-1" in text
    assert "+ магистрали" in text
    assert "Диктующая" in app.result_tree.set("101-1", "role")
    assert "Макс. мощность" in app.result_tree.set("101-2", "role")
    assert app.result_tree.winfo_height() >= 100, "Results must have usable room at 960×640."
    book = openpyxl.load_workbook(target, data_only=True)
    assert "Сводка" in book.sheetnames and "Ветки" in book.sheetnames
    summary_values = " ".join(str(cell.value) for row in book["Сводка"] for cell in row)
    assert "101-1" in summary_values and "101-2" in summary_values
    book.close()

    # The actual help buttons open modeless windows with independent content and search.
    for name, topic, expected in [
        ("Инструкция", "guide", "Excel"),
        ("Формулы и СП", "formulas", "СП"),
    ]:
        next(b for b in app.action_bar.buttons if b["text"] == name).invoke()
        app.update()
        window = app.help_windows[topic]
        assert expected in window.text.get("1.0", "end")
        assert app.grab_current() is None
        window.query.set(expected)
        window.find()
        assert window.text.tag_ranges("found")
        window.destroy()

    # Switching systems changes both summary and branch rows.
    second = copy.deepcopy(app.project["systems"][0])
    second["id"] = "2.1"
    app.project["systems"].append(second)
    branch = copy.deepcopy(app.project["branches"][0])
    branch.update(id="201-1", system_id="2.1", collector_id="201", main_path=[])
    app.project["branches"].append(branch)
    segment = copy.deepcopy(app.project["segments"][0])
    segment.update(id="201-1-подача-обратка", branch_id="201-1", length_m=10)
    app.project["segments"].append(segment)
    app.run()
    app.result_system.set("2.1")
    app.system_choice.event_generate("<<ComboboxSelected>>")
    app.update()
    assert app.result_tree.get_children() == ("201-1",)
    assert "Система 2.1:" in app.summary.get("1.0", "end")

    # Incomplete paths are candidates and never presented as final pump requirements.
    app.project["branches"][-1]["path_complete"] = False
    app.run()
    text = app.summary.get("1.0", "end")
    assert "Максимум учтённых потерь: 201-1" in text
    assert "Диктующее кольцо:" not in text
    assert "Для подбора насоса" not in text

    # Invalid inputs still have a clearly identified source-data export.
    app.project["segments"][0]["inner_mm"] = 0
    draft = folder / "Исходные данные.xlsx"
    with patch("app.messagebox.askyesno", return_value=True) as question, patch(
        "app.filedialog.asksaveasfilename", return_value=str(draft)
    ):
        assert app.export()
        assert question.called
    book = openpyxl.load_workbook(draft, data_only=True)
    assert "Готовность" in book.sheetnames
    assert "Расчёт в этой книге не выполнен" in book["Исходные данные"]["B3"].value
    assert "Ветки" not in book.sheetnames
    book.close()

    # A locked Excel file produces a recoverable action-specific message.
    app.project = demo_project()
    with patch("app.filedialog.asksaveasfilename", return_value=str(target)), patch(
        "app.export_results", side_effect=PermissionError("locked")
    ), patch("app.messagebox.showerror") as error:
        assert app.export() is False
        assert "Закройте его в Excel" in error.call_args.args[1]

    # Larger Windows-like text reflows actions rather than clipping export/help.
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        tkfont.nametofont(name).configure(size=14)
    app.geometry("961x680")
    visible_toolbar(app)
    assert app.result_tree.winfo_height() >= 75
    app.destroy()

print(
    "UI 0.3 OK: 960×640, larger text, automatic Excel export, draft export, file-lock handling, system choice, thermal/critical roles, built-in help."
)
